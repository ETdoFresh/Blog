﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Timers;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace SongInfo
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private bool isRunning = false;
        private bool isLogging = false;
        private Timer timer = new Timer();
        private string prevAlbum;
        private string prevTitle;
        private string prevArt;

        public MainWindow()
        {
            Log("Program Started");
            InitializeComponent();
            ReadFromConfig();

            if (RunAtStart.IsChecked.Value)
                StartRunning();

            isLogging = LogActivity.IsChecked.Value;
        }

        private void Run_Click(object sender, RoutedEventArgs e)
        {
            if (isRunning)
                StopRunning();
            else
                StartRunning();
        }

        private void StartRunning()
        {
            Run.Content = "Stop";
            RunStatus.Content = "Running...";
            isRunning = true;
            Log("Start Running Song Info Retriever");

            OnElapsed();
            var iteration = Convert.ToSingle(Iteration.Text);
            timer.Interval = float.IsNaN(iteration) ? 1000 : iteration * 1000;
            timer.Elapsed += OnElapsed;
            timer.Start();
        }

        private void OnElapsed(object sender, ElapsedEventArgs e)
        {
            Dispatcher.Invoke(OnElapsed);
        }

        private void OnElapsed()
        {
            using (var client = new System.Net.WebClient())
            {
                var jsonText = client.DownloadString(URLPath.Text);
                dynamic json = Newtonsoft.Json.JsonConvert.DeserializeObject(jsonText);
                for (int i = 0; i < JSONPath.Text.Split('>').Length; i++)
                    json = json[JSONPath.Text.Split('>')[i]];

                if (prevAlbum != json.album.ToString() && AlbumPath.Text.Trim().Length > 0)
                {
                    prevAlbum = json.album.ToString();
                    System.IO.File.WriteAllText(AlbumPath.Text, prevAlbum);
                }
                if (prevTitle != json.title.ToString() && TitlePath.Text.Trim().Length > 0)
                {
                    prevTitle = json.title.ToString();
                    System.IO.File.WriteAllText(TitlePath.Text, prevTitle);
                }
                if (prevArt != json.art.ToString() && ArtPath.Text.Trim().Length > 0)
                {
                    prevArt = json.art.ToString();
                    var uri = new Uri(URLPath.Text);
                    var path = uri.GetLeftPart(UriPartial.Authority);
                    path += prevArt;
                    path += "_240.jpg";
                    client.DownloadFile(path, ArtPath.Text);
                }
                Log("Download from {0} successfully", URLPath.Text);
                DownloadStatus.Content = "Download Successfully " + DateTime.Now.ToString();
            }
        }

        private void StopRunning()
        {
            Run.Content = "Run";
            RunStatus.Content = "Not Running...";
            isRunning = false;
            Log("Stop Song Info Retriever");
            timer.Elapsed -= OnElapsed;
            timer.Stop();
        }

        private void WriteToConfig_Click(object sender, RoutedEventArgs e)
        {
            var output = "";
            output += AlbumPath.Text + "\r\n";
            output += TitlePath.Text + "\r\n";
            output += ArtPath.Text + "\r\n";
            output += URLPath.Text + "\r\n";
            output += JSONPath.Text + "\r\n";
            output += Iteration.Text + "\r\n";
            output += LogActivity.IsChecked + "\r\n";
            output += RunAtStart.IsChecked + "\r\n";
            try
            {
                System.IO.File.WriteAllText("SongInfo.cfg", output);
                DownloadStatus.Content = "Above Settings have been written to SongInfo.cfg";
                Log("Wrote SongInfo.cfg");
            }
            catch
            {
                DownloadStatus.Content = "Could not write config to SongInfo.cfg";
                Log("Could not write SongInfo.cfg");
            }
        }

        private void ReadFromConfig()
        {
            try
            {
                var lines = System.IO.File.ReadAllLines("SongInfo.cfg");
                AlbumPath.Text = lines[0].Trim();
                TitlePath.Text = lines[1].Trim();
                ArtPath.Text = lines[2].Trim();
                URLPath.Text = lines[3].Trim();
                JSONPath.Text = lines[4].Trim();
                Iteration.Text = lines[5].Trim();
                LogActivity.IsChecked = Convert.ToBoolean(lines[6]);
                RunAtStart.IsChecked = Convert.ToBoolean(lines[7]);
                Log("Read SongInfo.cfg");
            }
            catch { }
        }

        private void Log(string format, params object[] args)
        {
            if (!isLogging)
                return;

            format = DateTime.Now + " - " + format + "\r\n";
            System.IO.File.AppendAllText("SongInfo.log", string.Format(format, args));
        }

        private void LogActivity_Checked(object sender, RoutedEventArgs e)
        {
            isLogging = LogActivity.IsChecked.Value;
        }
    }
}
