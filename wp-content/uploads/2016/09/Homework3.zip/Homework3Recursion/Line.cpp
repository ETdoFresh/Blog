#include "Line.h"

Line::Line()
	: Line(Vector4(0, 0, 0, 0), Vector4(0, 0, 0, 0)) { }

Line::Line(const Line& line)
{
	vertices[0] = Vector4(line.vertices[0]);
	vertices[1] = Vector4(line.vertices[1]);
}

Line::Line(float x0, float y0, float x1, float y1)
	: Line(Vector4(x0, y0, 0, 0), Vector4(x1, y1, 0, 0)) { }

Line::Line(float x0, float y0, float z0, float x1, float y1, float z1)
	: Line(Vector4(x0, y0, z0, 0), Vector4(x1, y1, z1, 0)) { }

Line::Line(const Vector2& vertex0, const Vector2& vertex1)
	: Line(Vector4(vertex0, 0, 0), Vector4(vertex1, 0, 0)) { }

Line::Line(const Vector3& vertex0, const Vector3& vertex1) :
	Line(Vector4(vertex0, 0), Vector4(vertex1, 0)) { }

Line::Line(const Vector4& vertex0, const Vector4& vertex1)
{
	this->vertices[0] = Vector4(vertex0);
	this->vertices[1] = Vector4(vertex1);
}

Line* Line::Split(const int numberOfSplits)
{
	int linesSize = numberOfSplits + 1;
	Line* lines = new Line[linesSize];
	Vector4 delta = vertices[1] - vertices[0];
	for (int i = 0; i < linesSize; i++)
	{
		lines[i] = Line(
			vertices[0] + (delta * i / linesSize),
			vertices[0] + (delta * (i+1)) / linesSize);
	}
	return lines;
}

Vector4 Line::GetVertex(int index)
{
	return vertices[index];
}

Vector2 Line::GetVertex2D(int index)
{
	return Vector2(vertices[index].x, vertices[index].y);
}

Line::~Line()
{
}
