#include "Angel.h"
#include "Line.h"

using namespace std;

const float sin60deg = sin(60 * DegreesToRadians);
const float cos60deg = cos(60 * DegreesToRadians);
int vertexCount = 0;

void init(int snowflakeIterations);
void display();
void keyboard(unsigned char key, int x, int y);
void LineLoop(Line triangle[], Vector2 v0, Vector2 v1, Vector2 v2);
Vector2* GetSnowFlake(int iterations);
Line* GetSnowFlakeLines(int& snowFlakeSize, Line* snowFlake, int iterations);

int main(int argc, char* argv[])
{
	int snowflakeIterations = 5;
	if (argc > 1)
		snowflakeIterations = std::atoi(argv[1]);

	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_RGBA);
	glutInitWindowSize(512, 512);
	glutCreateWindow("Homework3Recursion - Koch Snowflake - Edward Thomas Garcia");
#ifndef __APPLE__
	glewInit();
#endif
	init(snowflakeIterations);
	glutDisplayFunc(display);
	glutKeyboardFunc(keyboard);
	glutMainLoop();
	return 0;
}

void init(int snowflakeIterations)
{
	Vector2* points = GetSnowFlake(snowflakeIterations);

	GLuint vertexArray;
#ifdef __APPLE__
	glGenVertexArraysAPPLE(1, &vertexArray);
	glBindVertexArrayAPPLE(vertexArray);
#else
	glGenVertexArrays(1, &vertexArray);
	glBindVertexArray(vertexArray);
#endif

	GLuint buffer;
	glGenBuffers(1, &buffer);
	glBindBuffer(GL_ARRAY_BUFFER, buffer);
	glBufferData(GL_ARRAY_BUFFER, sizeof(Vector2) * vertexCount, points, GL_STATIC_DRAW);

#ifdef __APPLE__
	GLuint program = InitShader("vshaderhw3APPLE.glsl", "fshaderhw3APPLE.glsl");
#else
	GLuint program = InitShader("vshaderhw3.glsl", "fshaderhw3.glsl");
#endif

	glUseProgram(program);
	GLuint loc = glGetAttribLocation(program, "vPosition");
	glEnableVertexAttribArray(loc);
	glVertexAttribPointer(loc, 2, GL_FLOAT, GL_FALSE, 0, BUFFER_OFFSET(0));
	glClearColor(1, 1, 1, 1);
}

void display(void)
{
	glClear(GL_COLOR_BUFFER_BIT);
	glDrawArrays(GL_LINES, 0, vertexCount);
	glFlush();
}

void keyboard(unsigned char key, int x, int y)
{
	const unsigned char escapeKey = 033;
	if (key == escapeKey)
		exit(EXIT_SUCCESS);
}

void LineLoop(Line triangle[], Vector2 v0, Vector2 v1, Vector2 v2)
{
	triangle[0] = Line(v0, v1);
	triangle[1] = Line(v1, v2);
	triangle[2] = Line(v2, v0);
}

Vector2* GetSnowFlake(int iterations)
{
	Vector2 v[3] = { Vector2(-1, -0.4), Vector2(0, 1), Vector2(1, -0.4) };
	Line triangle[3] = { Line(v[0], v[1]), Line(v[1], v[2]), Line(v[2], v[0]) };
	int snowFlakeSize = 3;
	Line* snowFlake = GetSnowFlakeLines(snowFlakeSize, triangle, iterations);

	vertexCount = snowFlakeSize * 2;
	Vector2* points = new Vector2[vertexCount];
	for (int i = 0; i < snowFlakeSize; i++)
	{
		points[i * 2 + 0] = snowFlake[i].GetVertex2D(0);
		points[i * 2 + 1] = snowFlake[i].GetVertex2D(1);
	}
	return points;
}

Line* GetSnowFlakeLines(int& snowFlakeSize, Line* snowFlake, int iterations)
{
	if (iterations == 0)
		return snowFlake;

	Line* newSnowFlake = new Line[snowFlakeSize * 4];
	for (int i = 0; i < snowFlakeSize; i++)
	{
		Line* lineSplits = snowFlake[i].Split(2);
		newSnowFlake[i * 4 + 0] = lineSplits[0];
		newSnowFlake[i * 4 + 3] = lineSplits[2];

		Vector2 delta = lineSplits[1].GetVertex2D(1) - lineSplits[1].GetVertex2D(0);
		Vector2 bump;
		bump.x = delta.x * cos60deg - delta.y * sin60deg;
		bump.y = delta.x * sin60deg + delta.y * cos60deg;
		bump += lineSplits[1].GetVertex2D(0);

		newSnowFlake[i * 4 + 1] = Line(lineSplits[1].GetVertex2D(0), bump);
		newSnowFlake[i * 4 + 2] = Line(bump, lineSplits[1].GetVertex2D(1));
	}
	snowFlakeSize *= 4;
	return GetSnowFlakeLines(snowFlakeSize, newSnowFlake, iterations - 1);
}