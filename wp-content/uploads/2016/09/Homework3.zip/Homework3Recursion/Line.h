#pragma once
#include "Angel.h"
typedef vec2 Vector2;
typedef vec3 Vector3;
typedef vec4 Vector4;

class Line
{
public:
	Line();
	Line(const Line& line);
	Line(float x0, float y0, float x1, float y1);
	Line(float x0, float y0, float z0, float x1, float y1, float z1);
	Line(const Vector2& vertex0, const Vector2& vertex1);
	Line(const Vector3& vertex0, const Vector3& vertex1);
	Line(const Vector4& vertex0, const Vector4& vertex1);
	Line* Split(int numberOfSplits);
	Vector4 GetVertex(int index);
	Vector2 GetVertex2D(int index);
	~Line();
private:
	Vector4 vertices[2];
};