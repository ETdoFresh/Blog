#include "Angel.h"
#include "Line.h"

using namespace std;

int SNOWFLAKE_ITERATIONS = 5;
const int SPLIT_COUNT = 4;
const int STARTING_LINE_COUNT = 3;
int LINE_COUNT = STARTING_LINE_COUNT * pow(SPLIT_COUNT, SNOWFLAKE_ITERATIONS);
int VERTEX_COUNT = LINE_COUNT * 2;
const float sin60deg = sin(60 * DegreesToRadians);
const float cos60deg = cos(60 * DegreesToRadians);

void SetSnowflakeIterations(int iterations);
void init();
void display();
void keyboard(unsigned char key, int x, int y);
void LineLoop(Line triangle[], Vector2 v0, Vector2 v1, Vector2 v2);
void GetSnowFlake(int pointCount, Vector2* points);

int main(int argc, char* argv[])
{
	if (argc > 1)
		SetSnowflakeIterations(std::atoi(argv[1]));

	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_RGBA);
	glutInitWindowSize(512, 512);
	glutCreateWindow("Homework3 - Koch Snowflake - Edward Thomas Garcia");
#ifndef __APPLE__
	glewInit();
#endif
	init();
	glutDisplayFunc(display);
	glutKeyboardFunc(keyboard);
	glutMainLoop();
	return 0;
}

void SetSnowflakeIterations(int iterations)
{
	SNOWFLAKE_ITERATIONS = iterations;
	LINE_COUNT = STARTING_LINE_COUNT * pow(SPLIT_COUNT, SNOWFLAKE_ITERATIONS);
	VERTEX_COUNT = LINE_COUNT * 2;
}

void init(void)
{
	Vector2* points = new Vector2[VERTEX_COUNT];
	GetSnowFlake(VERTEX_COUNT, points);

	GLuint vertexArray;
#ifdef __APPLE__
	glGenVertexArraysAPPLE(1, &vertexArray);
	glBindVertexArrayAPPLE(vertexArray);
#else
	glGenVertexArrays(1, &vertexArray);
	glBindVertexArray(vertexArray);
#endif

	GLuint buffer;
	glGenBuffers(1, &buffer);
	glBindBuffer(GL_ARRAY_BUFFER, buffer);
	glBufferData(GL_ARRAY_BUFFER, sizeof(Vector2) * VERTEX_COUNT, points, GL_STATIC_DRAW);

#ifdef __APPLE__
	GLuint program = InitShader("vshaderhw3APPLE.glsl", "fshaderhw3APPLE.glsl");
#else
	GLuint program = InitShader("vshaderhw3.glsl", "fshaderhw3.glsl");
#endif

	glUseProgram(program);
	GLuint loc = glGetAttribLocation(program, "vPosition");
	glEnableVertexAttribArray(loc);
	glVertexAttribPointer(loc, 2, GL_FLOAT, GL_FALSE, 0, BUFFER_OFFSET(0));
	glClearColor(1, 1, 1, 1);
}

void display(void)
{
	glClear(GL_COLOR_BUFFER_BIT);
	glDrawArrays(GL_LINES, 0, VERTEX_COUNT);
	glFlush();
}

void keyboard(unsigned char key, int x, int y)
{
	const unsigned char escapeKey = 033;
	if (key == escapeKey)
		exit(EXIT_SUCCESS);
}

void LineLoop(Line triangle[], Vector2 v0, Vector2 v1, Vector2 v2)
{
	triangle[0] = Line(v0, v1);
	triangle[1] = Line(v1, v2);
	triangle[2] = Line(v2, v0);
}

void GetSnowFlake(int pointCount, Vector2* points)
{
	Line triangle[3];
	LineLoop(triangle, Vector2(-1, -0.4), Vector2(0, 1), Vector2(1, -0.4));
	
	int snowFlakeSize = 3;
	Line* snowFlake = new Line[snowFlakeSize];
	for (int i = 0; i < snowFlakeSize; i++)
		snowFlake[i] = triangle[i];

	for (int i = 0; i < SNOWFLAKE_ITERATIONS; i++)
	{
		Line* newSnowFlake = new Line[snowFlakeSize * 4];
		for (int j = 0; j < snowFlakeSize; j++)
		{
			Line* lineSplits = snowFlake[j].Split(2);
			newSnowFlake[j * 4 + 0] = lineSplits[0];
			newSnowFlake[j * 4 + 3] = lineSplits[2];

			Vector2 delta = lineSplits[1].GetVertex2D(1) - lineSplits[1].GetVertex2D(0);
			Vector2 bump;
			bump.x = delta.x * cos60deg - delta.y * sin60deg;
			bump.y = delta.x * sin60deg + delta.y * cos60deg;
			bump += lineSplits[1].GetVertex2D(0);

			newSnowFlake[j * 4 + 1] = Line(lineSplits[1].GetVertex2D(0), bump);
			newSnowFlake[j * 4 + 2] = Line(bump, lineSplits[1].GetVertex2D(1));
		}
		snowFlakeSize *= 4;
		snowFlake = newSnowFlake;
	}

	for (int i = 0; i < LINE_COUNT; i++)
	{
		points[i * 2 + 0] = snowFlake[i].GetVertex2D(0);
		points[i * 2 + 1] = snowFlake[i].GetVertex2D(1);
	}
}