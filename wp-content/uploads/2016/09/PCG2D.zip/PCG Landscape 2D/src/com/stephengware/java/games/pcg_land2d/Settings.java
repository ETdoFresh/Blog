package com.stephengware.java.games.pcg_land2d;

/**
 * Settings for this project.
 * 
 * @author Stephen G. Ware
 */
public class Settings {

	/** Name of the application */
	public static final String NAME = "Procedurally Generated 2D Landscape";
	
	/** Width of the PCG landscape */
	public static final int PANEL_WIDTH = 800;
	
	/** Height of the PCG landscape */
	public static final int PANEL_HEIGHT = 400;
}
