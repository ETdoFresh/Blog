package com.stephengware.java.games.pcg_land2d;

import java.awt.Point;
import java.util.Random;

/**
 * Displays the landscape and shapes it using a random fractal via the midpoint
 * displacement algorithm.
 * 
 * @author Stephen G. Ware
 */
public class Main {

	/** A random number generator */
	private static final Random random = new Random();
	
	/** The landscape to be reshaped */
	private static final Landscape landscape = new Landscape();
	
	/** The JFrame to display the landscape */
	private static LandscapeFrame frame;
	
	/**
	 * Runs the application.
	 * 
	 * @param args ignored
	 */
	public static void main(String[] args) {
		frame = new LandscapeFrame(landscape);
		// Make the first call to #shape to start the recursive process.  The
		// first line segment to modify is the entire landscape, which is
		// defined by landscape#left and landscape#right.  The maximum amount
		// by which the midpoint can be displaced is half the height of the
		// window (aka Settings#PANEL_HEIGHT).
		
	}
	
	/**
	 * A recursive method that applies the midpoint displacement algorithm
	 * to reshape a landscape into a random fractal.
	 * 
	 * @param left the leftmost point of the line segment to be modified
	 * @param right the rightmost point of the line segment to be modified
	 * @param maxHeight the maximum amount by which the midpoint can be
	 * displaced up or down
	 */
	private static void shape(Point left, Point right, int maxHeight) {
		pause();
		// Base case: If the maxHeight is below a certain small number, then
		// stop modifying the landscape.  Larger numbers will result in a more
		// jagged landscape, whereas smaller numbers will result in a smoother
		// landscape.
		
		// Calculate the X and Y coordinates of the line segment midpoint.
		int midx;
		int midy;
		// Use random#nextBoolean to randomly decide if the midpoint will be
		// displaced upwards or downwards.  Use random#nextInt bounded by the
		// maximum height to raise or lower the Y value of the midpoint.
		
		// Construct an instance of java.awt.Point with the midpoint
		// coordinates.
		Point mid;
		// Add that point to the landscape using landscape#add(Point).
		
		// Now make two recursive calls to this same method: one for the left
		// half of the line and one for the right half.  You should also reduce
		// the maxHeight by some factor (e.g. divide by 2) to ensure that the
		// fractal is not too jagged.
		
	}
	
	/**
	 * Waits 1/10 of a second and redraws the landscape on the screen.
	 */
	private static final void pause() {
		frame.repaint();
		try { Thread.sleep(100); }
		catch(InterruptedException ex) {}
	}
}
