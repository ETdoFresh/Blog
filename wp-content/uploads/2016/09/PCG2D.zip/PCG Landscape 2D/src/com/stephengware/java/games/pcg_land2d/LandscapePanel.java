package com.stephengware.java.games.pcg_land2d;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.geom.AffineTransform;

import javax.swing.JPanel;

/**
 * An instance of {@link javax.swing.JPanel} for drawing a {@link Landscape}
 * to the screen.
 * 
 * @author Stephen G. Ware
 */
public class LandscapePanel extends JPanel {
	
	/** Version 1.0 */
	private static final long serialVersionUID = 1L;
	
	/** The landscape to draw */
	public final Landscape landscape;

	/**
	 * Constructs a new panel for the given landscape.
	 * 
	 * @param landscape the landscape to draw
	 */
	public LandscapePanel(Landscape landscape) {
		this.landscape = landscape;
		setPreferredSize(new Dimension(Settings.PANEL_WIDTH, Settings.PANEL_HEIGHT));
	}
	
	@Override
	public void paintComponent(Graphics g) {
		super.paintComponent(g);
		Graphics2D g2d = (Graphics2D) g;
		AffineTransform transform = g2d.getTransform();
		transform.scale(1, -1);
		transform.translate(0, -Settings.PANEL_HEIGHT);
		g2d.setTransform(transform);
		g2d.setColor(Color.WHITE);
		g2d.fillRect(0, 0, Settings.PANEL_WIDTH, Settings.PANEL_HEIGHT);
		g2d.setColor(Color.BLACK);
		g2d.fillPolygon(landscape.getPolygon());
	}
}
