#ifndef POINT_H
#define POINT_H

class point 
{
protected:
    // Constructor and Destructor declaration
    point ( );
    point ( const unsigned int _extent );
    point ( const realVec& _realVec );
    point ( const point& _rhs );
    virtual ~point ( );

public:
    // Overloaded operators
    virtual bool operator== ( const point& rhs ) const; // equal-to
    realVec operator- ( const point& rhs ) const; // binary -

    // Coordinate Related Operations
    const realVec getCoords ( ) const { return itsCoords; }

    const PCReal getCoords ( PCIndex _index ) const
    {
        if (_index < PCIndex(itsCoords.size()))
            return itsCoords[_index];
        else
            throw xNotFound();
    }

    virtual void setCoords ( const realVec& _realVec );

    virtual void transform(const PCTransform& _transform,
                           const bool& _recursive = true,
                           const bool& _forward   = true) = 0;


protected:
    void setup ( const unsigned int _extent );

protected:
    realVec itsCoords;

};

	// << operator needs to be defined outside of class
    ostream& operator<< ( ostream& os, const point& s );

#endif
