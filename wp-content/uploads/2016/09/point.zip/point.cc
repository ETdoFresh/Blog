/**
   @file point.cc
   Abstract class to model a point in arbitrary dimensional space
 */

#include "point.h"
#include "CMath.h"
#include "typedef.h"
#include <math.h>
#include <cmath>

#ifdef HAS_BOOST_SERIALIZE
BOOST_CLASS_EXPORT_GUID(point, "point")
#endif


/**
   Default constructor with no arguments - point coordinates will be uninitialized
 */
point::point ( )
{
#ifdef __POINT_DEBUG
    cout << "Point constructor called: "
         << "point::point ( ) "
         << endl;
#endif
    itsCoords.resize(0);
}

/**
   Constructor that defines the dimensionality of the coordinates of the point - point coordinates will be initialized to 0.0
   @param[in]     _dimension an unsigned int representing the dimensionality of the space in which the point was defined
 */
point::point ( const unsigned int _dimension )
{
    setup(_dimension);
#ifdef __POINT_DEBUG
    cout << "Point constructor called: "
         << "point::point ( ) "
         << endl;
#endif
}

/**
   Constructor that takes a vector of coordinates - all point coordinates will be initialized
   @param[in]     _coordsVec a vector with coordinates
 */
point::point ( const realVec&  _coordsVec )
{
    setup(_coordsVec.size());
    setCoords(_coordsVec);
#ifdef __POINT_DEBUG
    cout << "Point constructor called: " << endl
         << "point::point ( const realVec& ) "
         << endl;
#endif
}


/**
   Copy Constructor
   @param[in]     _rhs a reference to the point to be copied
   @returns       a copy of the point _rhs
 */
point::point ( const point& _rhs )
{
#ifdef __POINT_DEBUG
    cout << "Point copy constructor called " << endl;
#endif
    setup(_rhs.getCoords().size());
    setCoords(_rhs.getCoords());
}

/**
   Destructor
   no allocation of memory in this class so no memory cleanup needed
 */
point::~point ( )
{
#ifdef __POINT_DEBUG
    cout << "Point destructor called" << endl;
#endif
}

/**
   A method to set the seed
   @param[in]     _dimension An unsigned int with the dimension of the space in which the point is defined
 */
void point::setup ( const unsigned int _dimension )
{
    itsCoords.resize(_dimension);
    for (unsigned int i=0; i<_dimension; i++)
    {
        itsCoords[i] = 0.00;
    }
}



/**
   Overloaded equal-to operator
   @param[in]     _rhs is a point on the right of the operator
   @returns       true if the absolute value of difference between each coordinate is less than or equal to COORDINATE_TOLERANCE
 */
bool point::operator== ( const point& _rhs ) const
{
    realVec tempRHSCoord = _rhs.getCoords();
    for (int i=0; i<itsCoords.size(); i++)
    {
        if (abs(itsCoords[i] - tempRHSCoord[i]) > COORDINATE_TOLERANCE)
        {
            return false;
        }
    }
    return true;
}

/**
   Overloaded subtraction operator
   @param[in]     _rhs is a point on the right of the subtraction operator
   @returns       a point whose coords are equal to the original point's coords minus the coords of _rhs
 */
realVec point::operator- ( const point& _rhs ) const
{
    realVec coords(itsCoords.size());
    realVec rhsCoords = _rhs.getCoords();
    for (int i=0; i<itsCoords.size(); i++)
    {
        coords[i] = itsCoords[i] - rhsCoords[i];
    }
    return coords;
}


/**
   coordinate setting operation
   @param[in]     _realVec represents a location in the local frame
   @returns       void
   @throw         xOutOfBounds in cases where we are changing the number of dimensions in the basis set
 */
void point::setCoords ( const realVec& _realVec )
{
    if (itsCoords.size() == _realVec.size())
    {
        for (int i=0; i< itsCoords.size(); i++)
        {
            itsCoords[i] = _realVec[i];
        }
    	//setChanged(true);
    	//notifyObservers();
    }
	else
	{
		string msg = "coordinates not the right size";
		string func = "void point::setCoords ( const realVec& _realVec )";
		throw xOutOfBounds(func,msg);
	}
}


/**
   outputs all point information into an output stream
   @param[in]     _deep if true, also call this function in an sub-objects this object may contain
   @param[in]     _os a reference to the target output stream
 */
void point::printEverything ( const bool& _deep, ostream& _os ) const
{
    if (_os.good())
    {
        for (int i=0; i< itsCoords.size(); i++)
        {
            _os << itsCoords[i] << " ";
        }
        _os << endl;
    }
    else
        cerr << "ERROR -- Unable to execute point::printEverything()!" << endl;
}

/**
   Overloaded stream redirection operator
   @param[in]     _os a reference to the target output stream
   @param[in]     _s a reference to the target point
   @returns       a reference to the target output stream for chaining purposes
 */
ostream& operator<< ( ostream& _os, const point& _s )
{
    realVec tempcoord = _s.getCoords();
    for (int i=0; i<tempcoord.size(); i++)
    {
        _os << tempcoord[i];
        if (i < tempcoord.size() -1)
        {
            _os << "\t";
        }
    }
    return _os;
}


