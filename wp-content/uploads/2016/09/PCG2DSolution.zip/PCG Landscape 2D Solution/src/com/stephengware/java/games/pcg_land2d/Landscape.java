package com.stephengware.java.games.pcg_land2d;

import java.awt.Point;
import java.awt.Polygon;
import java.util.ArrayList;
import java.util.Comparator;

/**
 * A black and white procedurally generated mountain range landscape.
 * 
 * @author Stephen G. Ware
 */
public class Landscape {

	/** Sorts a list of points from lowest to highest by their X coordinate */
	private static final Comparator<Point> SORT_ASCENDING_X = new Comparator<Point>(){

		@Override
		public int compare(Point p1, Point p2) {
			return p1.x - p2.x;
		}
	};
	
	/** The far left point of the landscape */
	public final Point left = new Point(0, Settings.PANEL_HEIGHT / 2);
	
	/** The far right point of the landscape */
	public final Point right = new Point(Settings.PANEL_WIDTH, Settings.PANEL_HEIGHT / 2);
	
	/** A list of points that define the line segments used to draw the landscape */
	private final ArrayList<Point> points = new ArrayList<>();
	
	/**
	 * Constructs a new, flat landscape.
	 */
	public Landscape() {
		points.add(left);
		points.add(right);
	}
	
	/**
	 * Adds a new vertex to the landscape polygon.  Points can be added in any
	 * order, but will always be displayed from left (lowest X) to right
	 * (highest X) when being drawn.
	 * 
	 * @param point the new vertex
	 */
	public void add(Point point) {
		points.add(point);
	}
	
	/**
	 * Returns a polygon in the shape of the landscape.
	 * 
	 * @return a polygon
	 */
	public final Polygon getPolygon() {
		Polygon polygon = new Polygon();
		polygon.addPoint(Settings.PANEL_WIDTH, 0);
		polygon.addPoint(0, 0);
		points.sort(SORT_ASCENDING_X);
		for(Point point : points)
			polygon.addPoint(point.x, point.y);
		return polygon;
	}
}
