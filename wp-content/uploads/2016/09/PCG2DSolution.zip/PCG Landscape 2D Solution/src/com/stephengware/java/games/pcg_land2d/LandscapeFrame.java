package com.stephengware.java.games.pcg_land2d;

import java.awt.BorderLayout;

import javax.swing.JFrame;
import javax.swing.UIManager;

/**
 * An instance of {@link javax.swing.JFrame} to displaying a {@link Landscape}.
 * 
 * @author Stephen G. Ware
 */
public class LandscapeFrame extends JFrame {

	/** Version 1.0 */
	private static final long serialVersionUID = 1L;
	
	/**
	 * Constructs a new frame to display the given landscape.
	 * 
	 * @param landscape the landscape to draw
	 */
	public LandscapeFrame(Landscape landscape) {
		setTitle(Settings.NAME);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		try {
			UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
		}
		catch(Exception ex) {
			ex.printStackTrace();
		}
		getContentPane().setLayout(new BorderLayout());
		getContentPane().add(new LandscapePanel(landscape), BorderLayout.CENTER);
		setResizable(false);
		pack();
		setLocationRelativeTo(null);
		setVisible(true);
	}
}
