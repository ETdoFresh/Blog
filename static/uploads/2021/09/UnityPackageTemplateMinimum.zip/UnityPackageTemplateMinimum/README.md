# Unity Package Template (Minimum)

This is a bare minimum empty Unity Package Template to get started.

## Links

[How to install a Unity Package Manager Package via GIT Url](https://docs.unity3d.com/Manual/upm-ui-giturl.html)  
