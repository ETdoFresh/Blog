package com.stephengware.java.games.ai_game.bt.leaf;

import com.stephengware.java.games.ai_game.Game;
import com.stephengware.java.games.ai_game.graphics.Sprite;
import com.stephengware.java.games.ai_game.graphics.Tiles;

/**
 * The player moves one grid square to the right.  Returns false if that square
 * is blocked by an object.  The parameter (if any) is ignored.
 * 
 * @author Stephen G. Ware
 */
public class Right extends Animate {

	/**
	 * Constructs a new instance of the right behavior.
	 */
	public Right() {
		super("RIGHT", new int[]{Tiles.WALKING_RIGHT_1, Tiles.WALKING_RIGHT_2, Tiles.FACING_RIGHT}, 1, 0);
	}
	
	@Override
	public boolean execute(Sprite argument) {
		return super.execute(null);
	}
	
	@Override
	public boolean run(Sprite argument) {
		if(Game.getCharacter().getRight().blocksPath())
			return false;
		else
			return super.run(Game.getCharacter());
	}
}
