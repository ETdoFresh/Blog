package com.stephengware.java.games.ai_game.graphics;

/**
 * A special instance of {@link Sprite} that represents the player-controlled
 * character.  This class tracks the number of keys and bombs the player has.
 * It is expected that there will be exactly 1 of these in each level.
 * 
 * @author Stephen G. Ware
 */
public class Character extends Sprite {

	/** Number of keys the player has collected */
	protected int keys = 0;
	
	/** Number of bombs the player has collected */
	protected int bombs = 0;
	
	/**
	 * Constructs a new player-controlled character.
	 * 
	 * @param level the level to which this sprite belongs
	 * @param tile the current image to display
	 * @param x the location on the X axis
	 * @param y the location on the Y axis
	 */
	public Character(Level level, int tile, int x, int y) {
		super(level, tile, x, y, Level.WALL_LEVEL);
	}
	
	/**
	 * Returns true if the player has at least one key; false otherwise.
	 * 
	 * @return true if the player has at least one key, false otherwise
	 */
	public boolean hasKey() {
		return keys > 0;
	}
	
	/**
	 * Increases the number of keys the player has collected by 1.
	 */
	public void getKey() {
		keys++;
	}
	
	/**
	 * Decreases the number of keys the player has collected by 1.
	 */
	public void useKey() {
		keys--;
	}
	
	/**
	 * Returns true if the player has at least one bomb; false otherwise.
	 * 
	 * @return true if the player has at least one bomb, false otherwise
	 */
	public boolean hasBomb() {
		return bombs > 0;
	}
	
	/**
	 * Increases the number of bombs the player has collected by 1.
	 */
	public void getBomb() {
		bombs++;
	}
	
	/**
	 * Decreases the number of bombs the player has collected by 1.
	 */
	public void useBomb() {
		bombs--;
	}
}
