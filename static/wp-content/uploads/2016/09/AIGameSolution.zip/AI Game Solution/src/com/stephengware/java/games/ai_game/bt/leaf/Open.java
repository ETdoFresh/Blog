package com.stephengware.java.games.ai_game.bt.leaf;

import com.stephengware.java.games.ai_game.Game;
import com.stephengware.java.games.ai_game.Settings;
import com.stephengware.java.games.ai_game.bt.Leaf;
import com.stephengware.java.games.ai_game.graphics.Character;
import com.stephengware.java.games.ai_game.graphics.Sprite;
import com.stephengware.java.games.ai_game.graphics.Tiles;

/**
 * If the sprite directly above the player is a closed wooden door, the door is
 * opened and this behavior returns true.  Otherwise, this behavior returns
 * false.  The parameter (if any) is ignored.
 * 
 * @author Stephen G. Ware
 */
public class Open extends Leaf {

	/**
	 * Constructs a new instance of the open behavior.
	 */
	public Open() {
		super("OPEN");
	}
	
	@Override
	public boolean execute(Sprite argument) {
		return super.execute(null);
	}

	@Override
	protected boolean run(Sprite argument) {
		Character character = Game.getCharacter();
		Sprite above = character.getAbove();
		if(above.getTile() == Tiles.WOOD_DOOR_CLOSED) {
			character.setTile(Tiles.FACING_UP);
			above.move(0, 0, -1);
			above.setTile(Tiles.WOOD_DOOR_OPEN);
			Game.scene.repaint();
			Animate.pause(Settings.ANIMATION_DELAY * 2);
			return true;
		}
		else
			return false;
	}
}
