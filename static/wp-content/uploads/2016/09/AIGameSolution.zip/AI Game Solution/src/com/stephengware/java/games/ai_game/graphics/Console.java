package com.stephengware.java.games.ai_game.graphics;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import com.stephengware.java.games.ai_game.Settings;
import com.stephengware.java.games.ai_game.bt.Behaviors;

/**
 * A text console for displaying output to and collecting input from the
 * player.
 * 
 * @author Stephen G. Ware
 */
public class Console extends JPanel implements ActionListener {
	
	/** Version 1.0 */
	private static final long serialVersionUID = 1L;

	/** The text area to which output will be written */
	public final JTextArea output = new JTextArea();

	/** The text field from which input will be collected */
	public final JTextField input = new JTextField();
	
	/**
	 * Constructs a new text console.
	 */
	public Console() {
		setPreferredSize(Settings.PANE_SIZE);
		setMaximumSize(Settings.PANE_SIZE);
		setMinimumSize(Settings.PANE_SIZE);
		setLayout(new BorderLayout());
		output.setEditable(false);
		output.setBackground(Settings.FONT_BACKGROUND);
		output.setForeground(Settings.FONT_FOREGROUND);
		output.setFont(Settings.FONT);
		JScrollPane scroll = new JScrollPane(output, JScrollPane.VERTICAL_SCROLLBAR_NEVER, JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
		scroll.setBorder(null);
		add(scroll, BorderLayout.CENTER);
		input.setBackground(Settings.FONT_BACKGROUND);
		input.setForeground(Settings.FONT_FOREGROUND);
		input.setFont(Settings.FONT);
		input.setCaretColor(Settings.FONT_FOREGROUND);
		input.setBorder(null);
		input.addActionListener(this);
		add(input, BorderLayout.SOUTH);
		setBorder(BorderFactory.createLineBorder(Settings.FONT_BACKGROUND, 10));
	}

	/**
	 * Appends output to the console.
	 * 
	 * @param string the text to append
	 */
	public void append(String string) {
		System.out.print("\n" + string);
		output.append("\n" + string);
		output.setCaretPosition(output.getDocument().getLength());
	}
	
	/**
	 * Parse a command from the player and execute the behavior that it
	 * describes on a separate thread.
	 * 
	 * @param text the player's input
	 */
	public void parse(String text) {
		input.setEnabled(false);
		String verb, noun;
		if(text.indexOf(" ") != -1) {
			verb = text.substring(0, text.indexOf(" "));
			noun = text.substring(text.indexOf(" ") + 1);
		}
		else {
			verb = text;
			noun = null;
		}
		Thread thread = new Thread() {
			@Override
			public void run() {
				try {
					Behaviors.execute(verb, noun);
				}
				catch(IllegalArgumentException ex) {
					append(ex.getMessage());
				}
				input.setEnabled(true);
				input.requestFocus();
			}
		};
		thread.start();
	}
	
	@Override
	public void actionPerformed(ActionEvent event) {
		String text = input.getText();
		input.setText("");
		parse(text);
	}
}
