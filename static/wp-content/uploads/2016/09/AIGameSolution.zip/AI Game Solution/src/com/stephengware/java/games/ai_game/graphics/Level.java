package com.stephengware.java.games.ai_game.graphics;

import com.stephengware.java.games.ai_game.Settings;

/**
 * Represents an individual level in the game.  Each level is expected to have
 * exactly one player-controlled character and at least one flask.
 * 
 * @author Stephen G. Ware
 */
public class Level {

	/** The lowest Z axis level that appears under all others */
	public static final int FLOOR_LEVEL = 0;
	
	/** A Z axis level for objects with need to be drawn but do not obstruct the players's movement */
	public static final int OPEN_DOOR_LEVEL = 1;
	
	/** The Z axis level of the player and objects that obstruct the player's movement */
	public static final int WALL_LEVEL = 2;
	
	/** The Z axis level at which exploding bombs will be drawn */
	public static final int BOMB_LEVEL = 3;
	
	/** The highest defined Z axis level */
	public static final int LEVEL_TOP = BOMB_LEVEL;
	
	/** The array of sprites that make up the level */
	final Sprite[][] sprites = new Sprite[Settings.LEVEL_WIDTH * Settings.LEVEL_HEIGHT][LEVEL_TOP + 1];
	
	/** The player-controlled character */
	Character character = null;
	
	/**
	 * Constructs a level object with only grass and an outline of trees around
	 * the border.
	 */
	public Level() {
		grass(0, 0, Settings.LEVEL_WIDTH, Settings.LEVEL_HEIGHT);
		trees(0, 0, Settings.LEVEL_WIDTH, Settings.LEVEL_HEIGHT);
	}
	
	/**
	 * Creates a {@link Sprite} at the given X, Y, and Z position in this
	 * level.
	 * 
	 * @param tile the current image the sprite should display
	 * @param x the location on the X axis
	 * @param y the location on the Y axis
	 * @param z the location on the Z axis
	 * @return the newly created sprite
	 */
	public Sprite addSprite(int tile, int x, int y, int z) {
		if(Tiles.isCharacter(tile)) {
			character = new Character(this, tile, x, y);
			return character;
		}
		else
			return new Sprite(this, tile, x, y, z);
	}
	
	/**
	 * Fills a rectangular area with sprites of a given image.
	 * 
	 * @param tile the image all the newly created sprites will display
	 * @param x the location on the X axis of the top left corner
	 * @param y the location on the Y axis of the top left corner
	 * @param width the width of the rectangle
	 * @param height the height of the rectangle
	 * @param z the location on the Z axis
	 */
	private final void fill(int tile, int x, int y, int width, int height, int z) {
		for(int r=0; r<width; r++)
			for(int c=0; c<height; c++)
				addSprite(tile, x + r, y + c, z);
	}
	
	/**
	 * Draws the outline of a rectangular area with sprites of a given image.
	 * 
	 * @param tile the image all the newly created sprites will display
	 * @param x the location on the X axis of the top left corner
	 * @param y the location on the Y axis of the top left corner
	 * @param width the width of the rectangle
	 * @param height the height of the rectangle
	 * @param z the location on the Z axis
	 */
	private final void outline(int tile, int x, int y, int width, int height, int z) {
		fill(tile, x, y, width, 1, z);
		fill(tile, x, y + height - 1, width, 1, z);
		fill(tile, x, y + 1, 1, height - 2, z);
		fill(tile, x + width - 1, y + 1, 1, height - 2, z);
	}
	
	/**
	 * Draws a rectangle of grass.
	 * 
	 * @param x the location on the X axis of the top left corner
	 * @param y the location on the Y axis of the top left corner
	 * @param width the width of the rectangle
	 * @param height the height of the rectangle
	 */
	public void grass(int x, int y, int width, int height) {
		fill(Tiles.GRASS, x, y, width, height, FLOOR_LEVEL);
	}
	
	/**
	 * Draws the outline of a rectangle of trees.
	 * 
	 * @param x the location on the X axis of the top left corner
	 * @param y the location on the Y axis of the top left corner
	 * @param width the width of the rectangle
	 * @param height the height of the rectangle
	 */
	public void trees(int x, int y, int width, int height) {
		outline(Tiles.TREE, x, y, width, height, WALL_LEVEL);
	}
	
	/**
	 * Draws a wall with a given type of door.
	 * 
	 * @param x the location on the X axis of the top leftmost wall tile
	 * @param y the location on the Y axis of the top leftmost wall tile
	 * @param width the width of the wall
	 * @param door the image that the door sprite should display
	 */
	private void wall(int x, int y, int width, int door) {
		fill(Tiles.WALL_FRONT, x, y, width, 1, WALL_LEVEL);
		if(door != -1)
			addSprite(door, x + width / 2, y, WALL_LEVEL);
	}
	
	/**
	 * Draws a solid wall.
	 * 
	 * @param x the location on the X axis of the top leftmost wall tile
	 * @param y the location on the Y axis of the top leftmost wall tile
	 * @param width the width of the wall
	 */
	public void wall(int x, int y, int width) {
		wall(x, y, width, -1);
	}
	
	/**
	 * Draws a wall with an opening where the door would be.
	 * 
	 * @param x the location on the X axis of the top leftmost wall tile
	 * @param y the location on the Y axis of the top leftmost wall tile
	 * @param width the width of the wall
	 */
	public void openWall(int x, int y, int width) {
		wall(x, y, width, Tiles.WALL_FRONT);
	}
	
	/**
	 * Draws a wall with a closed wooden door.
	 * 
	 * @param x the location on the X axis of the top leftmost wall tile
	 * @param y the location on the Y axis of the top leftmost wall tile
	 * @param width the width of the wall
	 */
	public void unlockedWall(int x, int y, int width) {
		wall(x, y, width, Tiles.WOOD_DOOR_CLOSED);
	}
	
	/**
	 * Draws a wall with a closed metal door.
	 * 
	 * @param x the location on the X axis of the top leftmost wall tile
	 * @param y the location on the Y axis of the top leftmost wall tile
	 * @param width the width of the wall
	 */
	public void lockedWall(int x, int y, int width) {
		wall(x, y, width, Tiles.METAL_DOOR_CLOSED);
	}
	
	/**
	 * Draws a building consisting of 4 walls, a floor, and a given type of
	 * door.
	 * 
	 * @param x the location on the X axis of the top left corner
	 * @param y the location on the Y axis of the top left corner
	 * @param width the width of the building
	 * @param height the height of the building
	 * @param locked true if the door is locked, false if the door is unlocked
	 */
	public void building(int x, int y, int width, int height, boolean locked) {
		fill(Tiles.FLOOR, x, y, width, height, FLOOR_LEVEL);
		wall(x + 1, y, width - 2);
		if(locked)
			lockedWall(x, y + height - 1, width);
		else
			unlockedWall(x, y + height - 1, width);
		fill(Tiles.WALL_SIDE, x, y + 1, 1, height - 2, WALL_LEVEL);
		fill(Tiles.WALL_SIDE, x + width - 1, y + 1, 1, height - 2, WALL_LEVEL);
		addSprite(Tiles.WALL_BACK, x, y, FLOOR_LEVEL);
		addSprite(Tiles.WALL_BACK, x + width - 1, y, FLOOR_LEVEL);
	}
	
	/**
	 * Places the player controlled character in the level.
	 * 
	 * @param x the location on the X axis
	 * @param y the location on the Y axis
	 */
	public void character(int x, int y) {
		addSprite(Tiles.FACING_DOWN, x, y, WALL_LEVEL);
	}
	
	/**
	 * Places a key in the level.
	 * 
	 * @param x the location on the X axis
	 * @param y the location on the Y axis
	 */
	public void key(int x, int y) {
		addSprite(Tiles.KEY, x, y, WALL_LEVEL);
	}
	
	/**
	 * Places a bomb in the level.
	 * 
	 * @param x the location on the X axis
	 * @param y the location on the Y axis
	 */
	public void bomb(int x, int y) {
		addSprite(Tiles.BOMB, x, y, WALL_LEVEL);
	}
	
	/**
	 * Places a flask in the level.
	 * 
	 * @param x the location on the X axis
	 * @param y the location on the Y axis
	 */
	public void flask(int x, int y) {
		addSprite(Tiles.FLASK, x, y, WALL_LEVEL);
	}
}
