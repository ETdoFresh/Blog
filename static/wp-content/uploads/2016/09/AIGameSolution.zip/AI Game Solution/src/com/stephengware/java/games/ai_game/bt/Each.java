package com.stephengware.java.games.ai_game.bt;

import com.stephengware.java.games.ai_game.Game;
import com.stephengware.java.games.ai_game.graphics.Sprite;

/**
 * The 'EACH' behavior is an {@link Iterator} combined with a {@link Sequence}.
 * This means that, for some given type of object, this behavior will pass
 * every object of that type to its child as an argument until its child
 * returns false, and then this behavior will return false.  If the child never
 * returns false, this behavior returns true.
 * 
 * @author Stephen G. Ware
 */
public class Each extends Iterator {

	/**
	 * Constructs an 'EACH' behavior for a given type of object and a given
	 * child behavior.
	 * 
	 * @param type the type of object to iterate over
	 * @param children the child behavior
	 */
	public Each(String type, BehaviorTree[] children) {
		super("EACH_" + type, type, children);
	}

	@Override
	protected boolean run(Sprite argument) {
		for(Sprite sprite : Game.getAll(type))
			if(!child.execute(sprite))
				return false;
		return true;
	}
	
	@Override
	public String toString(Sprite argument) {
		return name;
	}
}
