package com.stephengware.java.games.ai_game.bt;

import com.stephengware.java.games.ai_game.graphics.Sprite;

/**
 * A sequence is a composite which will run each of its children in order
 * until one of them returns false and then this behavior returns false.  If no
 * child returns false, this behavior returns true.
 * 
 * @author Stephen G. Ware
 */
public class Sequence extends Composite {

	/**
	 * Constructs a new sequence with the given children.
	 * 
	 * @param children the children behaviors
	 */
	public Sequence(BehaviorTree...children) {
		super("SEQUENCE", children);
	}

	@Override
	protected boolean run(Sprite argument) {
		for(BehaviorTree child : children)
			if(!child.execute(argument))
				return false;
		return true;
	}
}
