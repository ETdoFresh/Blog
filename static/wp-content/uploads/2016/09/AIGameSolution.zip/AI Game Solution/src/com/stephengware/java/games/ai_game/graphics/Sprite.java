package com.stephengware.java.games.ai_game.graphics;

import java.awt.Graphics2D;

import com.stephengware.java.games.ai_game.Game;
import com.stephengware.java.games.ai_game.Settings;

/**
 * A sprite is an image (which can change) at a given location (which can
 * change).  A sprite belongs to exactly 1 level.  Sprites should not be
 * constructed directly; instead, you should use
 * {@link com.stephengware.java.games.ai_game.graphics.Level#addSprite(int, int, int, int)}.
 * 
 * @author Stephen G. Ware
 */
public class Sprite {

	/** The level this sprite belongs to */
	private final Level level;
	
	/** The current image the sprite is displaying */
	protected int tile;
	
	/** The sprite's current location on the X axis in grid squares*/
	protected int x;
	
	/** The sprite's current location on the Y axis in grid squares*/
	protected int y;
	
	/** A (positive or negative) number of pixels to offset the sprite on the X axis when drawing it on the grid */
	protected int xOffset = 0;
	
	/** A (positive or negative) number of pixels to offset the sprite on the Y axis when drawing it on the grid */
	protected int yOffset = 0;
	
	/** The sprite's current location on the Z axis */
	protected int z;
	
	/**
	 * Constructs a new sprite with a given image and location.
	 * 
	 * @param level the level this sprite belongs to
	 * @param tile the current image to display
	 * @param x the sprite's current location on the X axis
	 * @param y the sprite's current location on the Y axis
	 * @param z the sprite's current location on the Z axis
	 */
	Sprite(Level level, int tile, int x, int y, int z) {
		this.level = level;
		this.tile = tile;
		this.x = x;
		this.y = y;
		this.z = z;
		addToLevel();
	}
	
	/**
	 * Removes the sprite from its level.
	 */
	private final void removeFromLevel() {
		level.sprites[y * Settings.LEVEL_WIDTH + x][z] = null;
	}
	
	/**
	 * Adds the sprite to its level.
	 */
	private final void addToLevel() {
		level.sprites[y * Settings.LEVEL_WIDTH + x][z] = this;
	}
	
	/**
	 * Returns true if this sprite is the player-controlled character.
	 * 
	 * @return true if the sprite is the player, false otherwise
	 */
	public boolean isCharacter() {
		return Tiles.isCharacter(tile);
	}
	
	/**
	 * Returns true if this sprite is a wall or tree.
	 * 
	 * @return true if the sprite is a wall or tree, false otherwise
	 */
	public boolean isWall() {
		return Tiles.isWall(tile);
	}
	
	/**
	 * Returns true if this sprite is a wooden door.
	 * 
	 * @return true if the sprite is a door, false otherwise
	 */
	public boolean isDoor() {
		return Tiles.isDoor(tile);
	}
	
	/**
	 * Returns true if this sprite is a metal door.
	 * 
	 * @return true if the sprite is a lock, false otherwise
	 */
	public boolean isLock() {
		return Tiles.isLock(tile);
	}
	
	/**
	 * Returns true if this sprite is an item which can be picked up.
	 * 
	 * @return true if the sprite is an item, false otherwise
	 */
	public boolean isItem() {
		return Tiles.isItem(tile);
	}
	
	/**
	 * Returns true if this sprite blocks the player's movement.
	 * 
	 * @return true if the sprite blocks the player, false otherwise
	 */
	public boolean blocksPath() {
		return Tiles.blocksPath(tile) && z == Level.WALL_LEVEL;
	}
	
	/**
	 * Returns the current image that the sprite is displaying.
	 * 
	 * @return the image
	 */
	public int getTile() {
		return tile;
	}
	
	/**
	 * Returns the sprite's current location on the X axis in grid squares.
	 * 
	 * @return the X location
	 */
	public int getX() {
		return x;
	}
	
	/**
	 * Returns the sprite's current location on the Y axis in grid squares.
	 * 
	 * @return the Y location
	 */
	public int getY() {
		return y;
	}
	
	/**
	 * Returns the sprite's current location on the Z axis in grid squares.
	 * 
	 * @return the Z location
	 */
	public int getZ() {
		return z;
	}
	
	/**
	 * Set's the current image that the sprite will display.
	 * 
	 * @param tile the image to display
	 */
	public void setTile(int tile) {
		this.tile = tile;
	}
	
	/**
	 * Sets the sprite's current location.
	 * 
	 * @param x the new location on the X axis in grid squares
	 * @param y the new location on the Y axis in grid squares
	 * @param z the new location on the Z axis in grid squares
	 */
	public void setLocation(int x, int y, int z) {
		removeFromLevel();
		this.x = x;
		this.y = y;
		this.z = z;
		this.xOffset = 0;
		this.yOffset = 0;
		addToLevel();
	}
	
	/**
	 * Changes the sprite's current location by a given amount on each axis.
	 * 
	 * @param dx the sprite's change on the X axis in grid squares
	 * @param dy the sprite's change on the Y axis in grid squares
	 * @param dz the sprite's change on the Z axis in grid squares
	 */
	public void move(int dx, int dy, int dz) {
		setLocation(x + dx, y + dy, z + dz);
	}
	
	/**
	 * Changes the sprite's current offset by a given amount on each axis.
	 * 
	 * @param x the sprite's change on the X axis in pixels
	 * @param y the sprite's change on the Y axis in pixels
	 */
	public void offset(int x, int y) {
		int newXOffset = xOffset + x;
		int newYOffset = yOffset + y;
		int dx = newXOffset / Settings.TILE_WIDTH;
		int dy = newYOffset / Settings.TILE_HEIGHT;
		newXOffset %= Settings.TILE_WIDTH;
		newYOffset %= Settings.TILE_HEIGHT;
		move(dx, dy, 0);
		xOffset = newXOffset;
		yOffset = newYOffset;
	}
	
	/**
	 * Removes the sprite from its level.
	 */
	public void delete() {
		removeFromLevel();
	}
	
	/**
	 * Returns the sprite directly above this sprite or null if no such sprite
	 * exists.
	 * 
	 * @return the sprite above
	 */
	public Sprite getAbove() {
		if(y == 0)
			return null;
		else
			return Game.getSpriteAt(x, y - 1);
	}
	
	/**
	 * Returns the sprite directly below this sprite or null if no such sprite
	 * exists.
	 * 
	 * @return the sprite below
	 */
	public Sprite getBelow() {
		if(y == Settings.LEVEL_HEIGHT - 1)
			return null;
		else
			return Game.getSpriteAt(x, y + 1);
	}
	
	/**
	 * Returns the sprite directly to the left of this sprite or null if no
	 * such sprite exists.
	 * 
	 * @return the sprite to the left
	 */
	public Sprite getLeft() {
		if(x == 0)
			return null;
		else
			return Game.getSpriteAt(x - 1, y);
	}
	
	/**
	 * Returns the sprite directly to the right of this sprite or null if no
	 * such sprite exists.
	 * 
	 * @return the sprite to the right
	 */
	public Sprite getRight() {
		if(x == Settings.LEVEL_WIDTH - 1)
			return null;
		else
			return Game.getSpriteAt(x + 1, y);
	}
	
	/**
	 * Draw the current level on the screen.
	 * 
	 * @param graphics the graphics context on which to draw
	 */
	public void draw(Graphics2D graphics) {
		graphics.drawImage(Tiles.TILES[tile], x * Settings.TILE_WIDTH + xOffset, y * Settings.TILE_HEIGHT + yOffset, null);
	}

	@Override
	public String toString() {
		return getClass().getName() + "[tile=" + tile + ", x=" + x + ", y=" + y + ", z=" + z + "]";
	}
}
