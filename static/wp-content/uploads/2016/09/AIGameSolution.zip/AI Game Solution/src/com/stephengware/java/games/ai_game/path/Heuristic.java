package com.stephengware.java.games.ai_game.path;

import com.stephengware.java.games.ai_game.graphics.Sprite;

/**
 * A heuristic is a function for efficiently estimating the distance between
 * two locations.
 * 
 * @author Your Name
 */
public class Heuristic {

	/**
	 * Returns an estimate of the distance between the X and Y location of two
	 * {@link com.stephengware.java.games.ai_game.graphics.Sprite Sprite}s.
	 * This heuristic uses Manhattan distance, which is simply the sum of the
	 * differences between the X and Y coordinates of the two locations.
	 * This heuristic is admissible in a grid--that is, it will never
	 * overestimate the distance.  This heuristic ignores Z distance.
	 * 
	 * @param origin the first location
	 * @param destination the second location
	 * @return an estimate of the distance between them on the X and Y axes
	 */
	public static int evaluate(Sprite origin, Sprite destination) {
		// === Step 1 ===
		// Calculate the Manhattan distance between the origin and destination.
		return Math.abs(destination.getX() - origin.getX()) + Math.abs(destination.getY() - origin.getY());
	}
}
