package com.stephengware.java.games.ai_game.bt.leaf;

import com.stephengware.java.games.ai_game.Game;
import com.stephengware.java.games.ai_game.Settings;
import com.stephengware.java.games.ai_game.bt.Leaf;
import com.stephengware.java.games.ai_game.graphics.Sprite;

/**
 * An abstract parent of behaviors that require frequent changes to the
 * appearance or location of a sprite.  The parameter is the sprite that will
 * be changed.
 * 
 * @author Stephen G. Ware
 */
public abstract class Animate extends Leaf {

	/** The animation frames to cycle through */
	protected final int[] frames;
	
	/** The net change in the X component during the animation */
	protected final int dx;
	
	/** The net change in the Y component during the animation */
	protected final int dy;
	
	/**
	 * Constructs a new animation behavior.
	 * 
	 * @param name the name of the behavior
	 * @param frames the frames to cycle through during the animation
	 * @param dx the net change in X
	 * @param dy the net change in Y
	 */
	public Animate(String name, int[] frames, int dx, int dy) {
		super(name);
		this.frames = frames;
		this.dx = dx;
		this.dy = dy;
	}
	
	@Override
	protected boolean run(Sprite argument) {
		if(argument == null)
			return false;
		int xFinal = argument.getX() + dx;
		int yFinal = argument.getY() + dy;
		int zFinal = argument.getZ();
		int xMove = (this.dx * Settings.TILE_WIDTH) / frames.length;
		int yMove = (this.dy * Settings.TILE_HEIGHT) / frames.length;
		for(int i=0; i<frames.length - 1; i++) {
			argument.setTile(frames[i]);
			argument.offset(xMove, yMove);
			Game.scene.repaint();
			pause();
		}
		argument.setTile(frames[frames.length - 1]);
		argument.setLocation(xFinal, yFinal, zFinal);
		Game.scene.repaint();
		return true;
	}
	
	/**
	 * Wait a given number of milliseconds.
	 * 
	 * @param millis the number of millisecond to wait
	 */
	protected static final void pause(int millis) {
		try {
			Thread.sleep(millis);
		}
		catch(InterruptedException ex) {
			return;
		}
	}
	
	/**
	 * Wait exactly
	 * {@link com.stephengware.java.games.ai_game.Settings#ANIMATION_DELAY}
	 * milliseconds.
	 */
	protected static final void pause() {
		pause(Settings.ANIMATION_DELAY);
	}
}
