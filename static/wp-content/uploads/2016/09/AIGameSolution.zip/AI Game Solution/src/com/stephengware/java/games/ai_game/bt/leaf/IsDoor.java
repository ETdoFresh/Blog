package com.stephengware.java.games.ai_game.bt.leaf;

import com.stephengware.java.games.ai_game.bt.Leaf;
import com.stephengware.java.games.ai_game.graphics.Sprite;

/**
 * Returns true if the parameter is a closed wooden door.
 * 
 * @author Stephen G. Ware
 */
public class IsDoor extends Leaf {

	/**
	 * Constructs a new instance of the is door behavior.
	 */
	public IsDoor() {
		super("IS_DOOR");
	}

	@Override
	protected boolean run(Sprite argument) {
		if(argument == null)
			return false;
		else
			return argument.getAbove().isDoor();
	}
}
