package com.stephengware.java.games.ai_game;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;

import com.stephengware.java.games.ai_game.graphics.Level;
import com.stephengware.java.games.ai_game.graphics.Tiles;

/**
 * Settings for this project.
 * 
 * @author Stephen G. Ware
 */
public class Settings {

	/** The name displayed on the game window */
	public static final String NAME = "AI Game";
	
	/** Whether or not to show visual debugging information during pathfinding */
	public static final boolean PATH_DEBUG = false;
	
	/** The level at which the player starts the game */
	public static final int FIRST_LEVEL = 1;
	
	/** The depth past which behavior trees cannot nest their execution */
	public static final int BEHAVIOR_TREE_STACK_DEPTH = 20;
	
	/**
	 * Returns the URL of the image file resource containing the tiles.
	 * 
	 * @return the URL as a String
	 */
	private static final String getTileSheetURL() {
		String url = Tiles.class.getName();
		url = url.substring(0, url.length() - Tiles.class.getSimpleName().length());
		url = url.replace('.', '/');
		return "/" + url + "tiles.png";
	}
	
	/** Location of the image file resource containing the game's tiles */
	public static final String TILE_SHEET = getTileSheetURL();
	
	/** The width of an individual tile in pixels */
	public static final int TILE_WIDTH = 16;
	
	/** The height of an individual tile in pixels */
	public static final int TILE_HEIGHT = 16;
	
	/** The width of a level in tiles */
	public static final int LEVEL_WIDTH = 20;
	
	/** The height of a level in tiles */
	public static final int LEVEL_HEIGHT = 16;
	
	/** The number of times larger the graphics should appear on the screen */
	public static final int SCALE = 2;

	/** The total size of the graphics and console in pixels */
	public static final Dimension PANE_SIZE = new Dimension(TILE_WIDTH * LEVEL_WIDTH * SCALE, TILE_HEIGHT * LEVEL_HEIGHT * SCALE);
	
	/** The foreground color of the console font */
	public static final Color FONT_FOREGROUND = Color.white;
	
	/** The background color of the console font */
	public static final Color FONT_BACKGROUND = Color.black;
	
	/** The size of the console font */
	public static final int FONT_SIZE = 16;
	
	/** The type of font used in the console */
	public static final Font FONT = new Font(Font.MONOSPACED, Font.PLAIN, FONT_SIZE);
	
	/** The number of milliseconds to wait between frames during animation */
	public static final int ANIMATION_DELAY = 100;
	
	/** The message displayed in the console when the game starts */
	public static final String WELCOME_MESSAGE = "=== WELCOME TO " + NAME.toUpperCase() + " ===\n" +
			"Type commands to act.  The goal is to pick up the red flask.\n" +
			"Keys and bombs open locked doors.\n" +
			"Verbs: HAS_BOMB, HAS_KEY, UP, DOWN, LEFT, RIGHT,\n" +
			"TAKE, OPEN, BLAST, UNLOCK\n" +
			"Nouns: FLASK, KEY, BOMB, DOOR, LOCK (assumes nearest)\n";
	
	/**
	 * Returns the level corresponding to a given index.
	 * 
	 * @param level the index of the level to return
	 * @return the level
	 */
	public static final Level getLevel(int level) {
		switch(level) {
		case 1: return getLevel1();
		case 2: return getLevel2();
		case 3: return getLevel3();
		case 4: return getLevel4();
		case 5: return getLevel5();
		case 6: return getLevel6();
		case 7: return getLevel7();
		case 8: return getLevel8();
		case 9: return getLevel9();
		case 10: return getLevel10();
		case 11: return getLevel11();
		}
		return null;
	}
	
	/**
	 * Returns level 0
	 * 
	 * @return level 0
	 */
	public static final Level getLevel0() {
		Level level = new Level();
		level.character(9, 9);
		return level;
	}
	
	/**
	 * Returns level 1
	 * 
	 * @return level 1
	 */
	public static final Level getLevel1() {
		Level level = new Level();
		level.character(9, 9);
		level.flask(9, 7);
		return level;
	}
	
	/**
	 * Returns level 2
	 * 
	 * @return level 2
	 */
	public static final Level getLevel2() {
		Level level = new Level();
		level.character(9, 10);
		level.trees(3, 8, 14, 1);
		level.trees(6, 4, 1, 4);
		level.trees(12, 4, 1, 4);
		level.flask(9, 6);
		return level;
	}
	
	/**
	 * Returns level 3
	 * 
	 * @return level 3
	 */
	public static final Level getLevel3() {
		Level level = new Level();
		level.character(9, 10);
		level.building(7, 2, 5, 5, false);
		level.flask(9, 4);
		return level;
	}
	
	/**
	 * Returns level 4
	 * 
	 * @return level 4
	 */
	public static final Level getLevel4() {
		Level level = new Level();
		level.character(9, 12);
		level.building(7, 2, 5, 8, false);
		level.unlockedWall(8, 6, 3);
		level.flask(9, 4);
		return level;
	}
	
	/**
	 * Returns level 5
	 * 
	 * @return level 5
	 */
	public static final Level getLevel5() {
		Level level = new Level();
		level.character(11, 10);
		level.building(7, 2, 5, 5, true);
		level.bomb(7, 9);
		level.flask(9, 4);
		return level;
	}
	
	/**
	 * Returns level 6
	 * 
	 * @return level 6
	 */
	public static final Level getLevel6() {
		Level level = new Level();
		level.character(9, 13);
		level.building(7, 2, 5, 9, true);
		level.lockedWall(8, 6, 3);
		level.bomb(7, 12);
		level.bomb(9, 8);
		level.flask(9, 4);
		return level;
	}
	
	/**
	 * Returns level 7
	 * 
	 * @return level 7
	 */
	public static final Level getLevel7() {
		Level level = new Level();
		level.character(11, 10);
		level.building(7, 2, 5, 5, true);
		level.key(7, 9);
		level.flask(9, 4);
		return level;
	}
	
	/**
	 * Returns level 8
	 * 
	 * @return level 8
	 */
	public static final Level getLevel8() {
		Level level = new Level();
		level.character(9, 13);
		level.building(7, 2, 5, 9, true);
		level.lockedWall(8, 6, 3);
		level.key(7, 12);
		level.bomb(9, 8);
		level.flask(9, 4);
		return level;
	}
	
	/**
	 * Returns level 9
	 * 
	 * @return level 9
	 */
	public static final Level getLevel9() {
		Level level = new Level();
		level.character(9, 13);
		level.building(4, 2, 5, 5, false);
		level.building(11, 2, 5, 9, true);
		level.lockedWall(12, 6, 3);
		level.key(6, 4);
		level.bomb(13, 8);
		level.flask(13, 4);
		return level;
	}
	
	/**
	 * Returns level 10
	 * 
	 * @return level 10
	 */
	public static final Level getLevel10() {
		Level level = new Level();
		level.character(9, 13);
		level.building(5, 2, 5, 4, false);
		level.key(7, 3);
		level.building(2, 7, 5, 4, false);
		level.key(7, 3);
		level.building(11, 2, 5, 9, true);
		level.lockedWall(12, 6, 3);
		level.bomb(13, 8);
		level.flask(13, 4);
		return level;
	}
	
	/**
	 * Returns level 22
	 * 
	 * @return level 11
	 */
	public static final Level getLevel11() {
		Level level = new Level();
		level.character(9, 13);
		level.building(3, 2, 6, 5, true);
		level.building(11, 2, 5, 9, true);
		level.lockedWall(12, 6, 3);
		level.key(5, 4);
		level.key(6, 4);
		level.bomb(5, 8);
		level.flask(13, 4);
		return level;
	}
}
