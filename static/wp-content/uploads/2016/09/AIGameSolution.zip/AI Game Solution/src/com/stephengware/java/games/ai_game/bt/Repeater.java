package com.stephengware.java.games.ai_game.bt;

import com.stephengware.java.games.ai_game.Game;
import com.stephengware.java.games.ai_game.graphics.Character;
import com.stephengware.java.games.ai_game.graphics.Sprite;

/**
 * A repeater is a decorator that runs its child over and over until it returns
 * true and then returns true.  As a failsafe mechanism, this repeater will
 * return false if the player-controlled character does not move at all during
 * the execution of the child.  This helps to prevent some infinite loops.
 * 
 * @author Stephen G. Ware
 */
public class Repeater extends Decorator {
	
	/**
	 * Constructs a repeater with the given child behavior.
	 * 
	 * @param children the child behavior (must be length exactly 1)
	 */
	public Repeater(BehaviorTree[] children) {
		super("REPEATOR", children);
	}
	
	@Override
	protected boolean run(Sprite argument) {
		Character character = Game.getCharacter();
		int x = character.getX();
		int y = character.getY();
		while(true) {
			if(child.execute(argument))
				return true;
			if(character.getX() == x && character.getY() == y)
				break;
			x = character.getX();
			y = character.getY();
		}
		return false;
	}
}
