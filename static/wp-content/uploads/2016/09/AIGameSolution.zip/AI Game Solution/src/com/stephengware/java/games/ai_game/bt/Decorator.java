package com.stephengware.java.games.ai_game.bt;

/**
 * A decorator is an internal node with exactly 1 child.
 * 
 * @author Stephen G. Ware
 */
public abstract class Decorator extends BehaviorTree {

	/** The child behavior */
	protected final BehaviorTree child;
	
	/**
	 * Constructs a new decorator with a given name and with the given
	 * child.  Exactly 1 child must be provided.
	 * 
	 * @param name the name of the behavior
	 * @param children the children behaviors (must be length exactly 1)
	 * @throws IllegalArgumentException if more or fewer than 1 child is
	 * provided
	 */
	public Decorator(String name, BehaviorTree[] children) {
		super(name);
		if(children.length != 1)
			throw new IllegalArgumentException(getClass().getSimpleName().toUpperCase() + " expects exaclty 1 child.");
		this.child = children[0];
	}
}
