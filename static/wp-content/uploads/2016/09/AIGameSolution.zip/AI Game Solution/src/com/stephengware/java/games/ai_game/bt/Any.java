package com.stephengware.java.games.ai_game.bt;

import com.stephengware.java.games.ai_game.Game;
import com.stephengware.java.games.ai_game.graphics.Sprite;

/**
 * The 'ANY' behavior is an {@link Iterator} combined with a {@link Selector}.
 * This means that, for some given type of object, this behavior will pass
 * every object of that type to its child as an argument until its child
 * returns true, and then this behavior will return true.  If the child never
 * returns true, this behavior returns false.
 * 
 * @author Stephen G. Ware
 */
public class Any extends Iterator {

	/**
	 * Constructs an 'ANY' behavior for a given type of object and a given
	 * child behavior.
	 * 
	 * @param type the type of object to iterate over
	 * @param children the child behavior
	 */
	public Any(String type, BehaviorTree[] children) {
		super("ANY_" + type, type, children);
	}

	@Override
	protected boolean run(Sprite argument) {
		for(Sprite sprite : Game.getAll(type))
			if(child.execute(sprite))
				return true;
		return false;
	}
	
	@Override
	public String toString(Sprite argument) {
		return name;
	}
}
