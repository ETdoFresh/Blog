package com.stephengware.java.games.ai_game.bt;

import com.stephengware.java.games.ai_game.Game;
import com.stephengware.java.games.ai_game.Settings;
import com.stephengware.java.games.ai_game.bt.leaf.*;
import com.stephengware.java.games.ai_game.graphics.Sprite;
import com.stephengware.java.games.ai_game.graphics.Tiles;

/**
 * A behavior tree is a modular, reusable, efficient way to create custom
 * intelligent behaviors from a set of simple actions.  This is the superclass
 * of all behavior trees.
 * 
 * @author Stephen G. Ware
 */
public abstract class BehaviorTree {

	/** The name of the behavior */
	public final String name;
	
	/** The number of times to indent a line before printing it */
	private static int indent = 0;
	
	/**
	 * Constructs a new behavior tree with the given name.
	 * 
	 * @param name the name of the behavior
	 */
	public BehaviorTree(String name) {
		this.name = name.toUpperCase();
	}
	
	/**
	 * Executes the behavior and returns the result.  This method prints
	 * various helpful bits of information and returns the result of
	 * {@link #run(Sprite)}, where the actual work is done.
	 * 
	 * @param argument the argument passed to this behavior
	 * @return true if the behavior succeeded, false otherwise
	 */
	public boolean execute(Sprite argument) {
		boolean shouldPrint = shouldPrint();
		String call = toString(argument).trim();
		if(shouldPrint && !(this instanceof Leaf))
			Game.console.append(indent() + call);
		indent++;
		boolean result;
		if(indent < Settings.BEHAVIOR_TREE_STACK_DEPTH) {
			try {
				result = run(argument);
			}
			catch(Exception ex) {
				ex.printStackTrace();
				result = false;
			}
		}
		else {
			Game.console.append(indent() + "STACK OVERFLOW");
			result = false;
		}
		indent--;
		if(shouldPrint)
			Game.console.append(indent() + call + ": " + (result ? "SUCCESS" : "FAILURE"));
		return result;
	}
	
	/**
	 * Check whether or not the information about this behavior should be
	 * printed to the console.  Information about walking (UP, DOWN, LEFT,
	 * RIGHT) is suppressed in most cases to avoid information overload.
	 * 
	 * @return true if information should be printed, false otherwise
	 */
	private final boolean shouldPrint() {
		if(getClass() == Up.class || getClass() == Down.class || getClass() == Left.class || getClass() == Right.class)
			return indent < 2 || Settings.PATH_DEBUG;
		else
			return true;
	}
	
	/**
	 * Return a string that is indented the correct number of times.
	 * 
	 * @return the indent string
	 */
	private static final String indent() {
		String str = "";
		for(int i=0; i<indent; i++)
			str += "| ";
		return str;
	}
	
	/**
	 * The actual work done by the behavior is done in this method.
	 * 
	 * @param argument the argument passes to the behavior
	 * @return true if the behavior succeeded, false otherwise
	 */
	protected abstract boolean run(Sprite argument);
	
	@Override
	public String toString() {
		return getClass().getName() + "[" + name + "]";
	}
	
	/**
	 * Returns a string representation of an individual call to this behavior
	 * with a given argument.
	 * 
	 * @param argument the argument passed to the behavior
	 * @return the string representation of this behavior with this argument
	 */
	public String toString(Sprite argument) {
		return name + " " + spriteToString(argument);
	}
	
	/**
	 * Return a string representation of the argument passed to this behavior.
	 * 
	 * @param sprite the argument passed to this behavior
	 * @return a string describing the argument
	 */
	protected static final String spriteToString(Sprite sprite) {
		if(sprite == null)
			return "";
		String string = "NOTHING";
		sprite = sprite.getAbove();
		if(sprite == null)
			return string;
		if(sprite.getTile() == Tiles.KEY)
			string = "KEY";
		else if(sprite.getTile() == Tiles.BOMB)
			string = "BOMB";
		else if(sprite.getTile() == Tiles.FLASK)
			string = "FLASK";
		else if(sprite.isDoor())
			string = "DOOR";
		else if(sprite.isLock())
			string = "LOCK";
		else if(sprite.isWall())
			string = "WALL";
		return string + " AT [" + sprite.getX() + "," + sprite.getY() + "]";
	}
}
