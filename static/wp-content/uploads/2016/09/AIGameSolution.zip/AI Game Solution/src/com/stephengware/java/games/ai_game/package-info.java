/**
 * This package contains a simple puzzle game that demonstrates two important
 * topics in artificial intelligence for games: A* pathfinding and behavior
 * trees.
 * 
 * <p>You should start by playing the game to get familiar with the basic
 * mechanics.  Type commands into the console on the left and see them
 * acted out on the right.  A number of simple behaviors are already included,
 * such as the ability to move around, test if your inventory contains items,
 * pick up items and use items.</p>
 * 
 * <p><b>Part 1: A* Pathfinding</b></p>
 * <p>Key pieces of code are missing from the classes in the
 * {@link com.stephengware.java.games.ai_game} package.</p>
 * <ul>
 *  <li>Steps 1 and 2: Complete
 *  {@link com.stephengware.java.games.ai_game.path.Heuristic} and
 *  {@link com.stephengware.java.games.ai_game.path.PriorityQueue#LOWEST_FIRST}
 *  so that they can be used to estimate the distance between two locations and
 *  sort locations into the proper order for the search process.</li>
 *  <li>Steps 3 and 4: Complete
 *  {@link com.stephengware.java.games.ai_game.path.PathSearch#search()} and
 *  {@link com.stephengware.java.games.ai_game.path.PathSearch#consider(Sprite, Sprite)},
 *  which perform the actual path search.</li>
 *  <li>Steps 5 and 6: Complete
 *  {@link com.stephengware.java.games.ai_game.path.PathSearch#walk()} and
 *  {@link com.stephengware.java.games.ai_game.path.PathSearch#walkTo(Sprite)},
 *  which reconstruct the path if a solution was found.</li>
 * </ul>
 * <p>After these steps are finished, you should be able to click on any
 * accessible location and see the character walk there via a shortest path.
 * </p>
 * 
 * <p>You may find it helpful to change
 * {@link com.stephengware.java.games.ai_game.Settings#PATH_DEBUG} to true to
 * display the contents of the history matrix during the search process.</p>
 * 
 * <p><b>Part 2: Behavior Trees</b></p>
 * <p>Once pathfinding is working, you can experiment with creating custom
 * behaviors using behavior trees.</p>
 * 
 * <p>Edit the contents of the 'behaviors.txt' file found in the
 * {@link com.stephengware.java.games.ai_game} package to define your own
 * behaviors.  The syntax for defining a tree looks like this:</p>
 * 
 * <pre>
 * GET
 * | SEQUENCE
 * | | WALK
 * | | TAKE
 * </pre>
 * 
 * <p>The top line assigns a name to the behavior.  To add children to a node,
 * list the names of node indented the appropriate number of times with the
 * string "| ".</p>
 * 
 * <p>The above example is a behavior named 'GET'.  It is a sequence of two
 * behaviors: WALK and TAKE.  When the player types the name of a behavior and
 * some argument into the console (e.g. 'GET FLASK') the behavior tree will be
 * executed with the given argument and its trace printed to the console like
 * so:</p>
 * 
 * <pre>
 * GET FLASK AT [9,7]
 * | SEQUENCE FLASK AT [9,7]
 * | | WALK FLASK AT [9,7]: SUCCESS
 * | | TAKE: SUCCESS
 * | SEQUENCE FLASK AT [9,7]: SUCCESS
 * GET FLASK AT [9,7]: SUCCESS
 * </pre>
 * 
 * <p>In addition to the pre-defined behaviors (leaf nodes), there are six kinds
 * of logical nodes:</p>
 * <ul>
 *  <li>{@link com.stephengware.java.games.ai_game.bt.Sequence}</li>
 *  <li>{@link com.stephengware.java.games.ai_game.bt.Selector}</li>
 *  <li>{@link com.stephengware.java.games.ai_game.bt.Inverter}</li>
 *  <li>{@link com.stephengware.java.games.ai_game.bt.Repeater}</li>
 *  <li>{@link com.stephengware.java.games.ai_game.bt.Each}</li>
 *  <li>{@link com.stephengware.java.games.ai_game.bt.Any}</li>
 * </ul>
 *  * 
 * <p>You can define any number of custom behaviors in the 'behaviors.txt'
 * file.  Try to define a set of behaviors that is intelligent enough that you
 * can win levels 1 - 10 by simply typing 'GET FLASK' into the console.</p>
 * 
 * <p>Level 11 demonstrates one of the key weaknesses of behavior trees: the
 * inability to plan ahead.</p>
 */
package com.stephengware.java.games.ai_game;