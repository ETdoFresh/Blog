package com.stephengware.java.games.ai_game.bt.leaf;

import com.stephengware.java.games.ai_game.Game;
import com.stephengware.java.games.ai_game.bt.Leaf;
import com.stephengware.java.games.ai_game.graphics.Sprite;
import com.stephengware.java.games.ai_game.path.PathSearch;

/**
 * Causes the player-controlled character to walk a path to the location given
 * as an argument (or returns false if not such path exists).
 * 
 * @author Stephen G. Ware
 */
public class Walk extends Leaf {

	/**
	 * Constructs a new instance of the walk behavior.
	 */
	public Walk() {
		super("WALK");
	}

	@Override
	protected boolean run(Sprite argument) {
		if(argument == null)
			return false;
		PathSearch path = new PathSearch(Game.getCharacter(), argument);
		Game.scene.setPathSearch(path);
		boolean result = path.search() != -1;
		Game.scene.setPathSearch(null);
		Game.scene.repaint();
		if(result)
			path.walk();
		return result;
	}
}
