package com.stephengware.java.games.ai_game.path;

import java.util.Comparator;
import java.util.Iterator;

import com.stephengware.java.games.ai_game.Game;
import com.stephengware.java.games.ai_game.Settings;
import com.stephengware.java.games.ai_game.graphics.Sprite;

/**
 * This queue holds the locations on the frontier of a {@link PathSearch} along
 * with data about their distance from the origin and destination.  Calls to
 * {@link #pop()} always return the location with the lowest combined distance
 * and heuristic value.
 * 
 * @author Stephen G. Ware
 */
public class PriorityQueue implements Iterable<Sprite> {

	/**
	 * A node stores an individual location, its distance from the origin, and
	 * its estimated distance to the destination.
	 * 
	 * @author Stephen G. Ware
	 */
	private final class Node {
		
		/** The location */
		public final Sprite sprite;
		
		/** The location's distance from the origin */
		public final int distance;
		
		/** An estimate of the location's distance to the destination */
		public final int heuristic;
		
		/**
		 * Creates a new node to store in the priority queue.
		 * 
		 * @param sprite the location
		 * @param distance the distance from the origin
		 * @param heuristic the estimated distance to the destination
		 */
		public Node(Sprite sprite, int distance, int heuristic) {
			this.sprite = sprite;
			this.distance = distance;
			this.heuristic = heuristic;
		}
	}
	
	/**
	 * This comparator defines the order in which nodes will be returned when
	 * {@link PriorityQueue#pop()} is called.  The compare
	 * method returns an integer.  That integer should be negative if the first
	 * node comes before the second node.  That integer should be positive if
	 * the second node comes before the first node.  Ties are broken greedily.
	 * That means that if a tie occurs, order the node with the lowest
	 * heuristic first.
	 * 
	 * @author Your Name
	 */
	private static final Comparator<Node> LOWEST_FIRST = new Comparator<Node>() {

		@Override
		public int compare(Node n1, Node n2) {
			// === Step 2 ===
			// This method needs to compare the distance and heuristic values
			// for the two givens nodes and return a negative number, 0, or a
			// positive number to determine their order in the queue.
			int comparison = (n1.distance + n1.heuristic) - (n2.distance + n2.heuristic);
			if(comparison == 0)
				comparison = n1.heuristic - n2.heuristic;
			return comparison;
		}
	};
	
	/**
	 * This {@link java.util.PriorityQueue} to stores the nodes.
	 */
	private final java.util.PriorityQueue<Node> queue = new java.util.PriorityQueue<>(LOWEST_FIRST);
	
	/**
	 * Returns true if this queue contains no nodes, false otherwise.
	 * 
	 * @return true if the queue is empty, false otherwise
	 */
	public boolean isEmpty() {
		return queue.isEmpty();
	}

	/**
	 * Adds a location to this priority queue, along with data about its
	 * distance from the origin and destination.
	 * 
	 * @param location the location
	 * @param distance the distance from the origin
	 * @param heuristic an estimate of the distance to the destination
	 */
	public void push(Sprite location, int distance, int heuristic) {	
		queue.add(new Node(location, distance, heuristic));
		if(Settings.PATH_DEBUG) {
			Game.scene.repaint();
			try{ Thread.sleep(Settings.ANIMATION_DELAY); }
			catch(InterruptedException ex){}
		}
	}
	
	/**
	 * Returns the location with the lowest combined distance and heuristic.
	 * 
	 * @return the next location used in the search
	 */
	public Sprite pop() {
		return queue.poll().sprite;
	}

	@Override
	public Iterator<Sprite> iterator() {
		return new MyIterator();
	}
	
	/**
	 * Iterates through all the locations in this queue in order.
	 * 
	 * @author Stephen G. Ware
	 */
	private final class MyIterator implements Iterator<Sprite> {

		/** The {@link java.util.PriorityQueue} iterator */
		private final Iterator<Node> iterator = queue.iterator();

		@Override
		public boolean hasNext() {
			return iterator.hasNext();
		}

		@Override
		public Sprite next() {
			return iterator.next().sprite;
		}
	}
}
