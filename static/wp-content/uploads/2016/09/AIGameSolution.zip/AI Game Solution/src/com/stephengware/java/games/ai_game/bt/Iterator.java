package com.stephengware.java.games.ai_game.bt;

import com.stephengware.java.games.ai_game.graphics.Sprite;

/**
 * An iterator is a decorator which ignores the argument that is passed to it
 * and instead passes each object of a given type to its child.
 * 
 * @author Stephen G. Ware
 */
public abstract class Iterator extends Decorator {

	/** The type of object to iterator over */
	protected final String type;
	
	/**
	 * Constructs an iterator with the given name, type of object, and child
	 * behavior.
	 * 
	 * @param name the name of the behavior
	 * @param type the type of object to iterator over
	 * @param children the child behavior (must be length exactly 1)
	 */
	public Iterator(String name, String type, BehaviorTree[] children) {
		super(name, children);
		this.type = type.toUpperCase();
	}
	
	@Override
	public String toString(Sprite argument) {
		return name + " " + type;
	}
}
