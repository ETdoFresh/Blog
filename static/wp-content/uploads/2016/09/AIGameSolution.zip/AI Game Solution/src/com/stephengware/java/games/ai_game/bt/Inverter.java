package com.stephengware.java.games.ai_game.bt;

import com.stephengware.java.games.ai_game.graphics.Sprite;

/**
 * An inverter is a decorator which runs its child and returns the opposite
 * of its result.
 * 
 * @author Stephen G. Ware
 */
public class Inverter extends Decorator {

	/**
	 * Constructs an inverter with the given child.
	 * 
	 * @param children the child behavior (must be length exactly 1)
	 */
	public Inverter(BehaviorTree[] children) {
		super("INVERTER", children);
	}

	@Override
	protected boolean run(Sprite argument) {
		return !child.execute(argument);
	}
}
