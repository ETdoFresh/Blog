package com.stephengware.java.games.ai_game.bt;

/**
 * A leaf node has no children and represents one of the simple pre-defined
 * behaviors out of which the behavior trees are constructed.
 * 
 * @author Stephen G. Ware
 */
public abstract class Leaf extends BehaviorTree {

	/**
	 * Constructs a leaf with the given name.
	 * 
	 * @param name the name of the behavior
	 */
	public Leaf(String name) {
		super(name);
	}
}
