package com.stephengware.java.games.ai_game;

import java.awt.BorderLayout;
import java.io.IOException;

import javax.swing.JFrame;
import javax.swing.UIManager;

import com.stephengware.java.games.ai_game.bt.Behaviors;

/**
 * The high-level container for a {@link Game}.
 * 
 * @author Stephen G. Ware
 */
public class GameFrame extends JFrame {

	/** Version 1 */
	private static final long serialVersionUID = 1L;

	/**
	 * Constructs a new window for the game.
	 */
	public GameFrame() {
		setTitle(Settings.NAME);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		try {
			UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
		}
		catch(Exception ex) {
			ex.printStackTrace();
		}
		getContentPane().setLayout(new BorderLayout());
		getContentPane().add(Game.gui, BorderLayout.CENTER);
		setResizable(false);
		pack();
		setLocationRelativeTo(null);
		Game.console.append(Settings.WELCOME_MESSAGE + Behaviors.getCustomBehaviors());
		Game.advanceLevel();
		Game.console.input.requestFocus();
		setVisible(true);
	}
	
	/**
	 * Runs the game.
	 * 
	 * @param args ignored
	 * @throws IOException if an IO error occurs while loading the game
	 */
	public static void main(String[] args) throws IOException {
		Game.load();
		new GameFrame();
	}
}
