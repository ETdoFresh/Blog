package com.stephengware.java.games.ai_game;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

/**
 * A suite of useful utility functions.
 * 
 * @author Stephen G. Ware
 */
public class Utilities {

	/**
	 * Reads a given resource in as a String.
	 * 
	 * @param file the path to the resource relative to the project root
	 * @return the resource, as a string
	 * @throws IOException if an IO error occurs
	 */
	public static final String getResourceAsString(String file) throws IOException {
		String url = Game.class.getName();
		url = url.substring(0, url.length() - Game.class.getSimpleName().length());
		url = url.replace('.', '/');
		url = "/" + url + file;
		InputStream in = Game.class.getResourceAsStream(url);
		InputStreamReader is = new InputStreamReader(in);
		StringBuilder sb = new StringBuilder();
		BufferedReader br = new BufferedReader(is);
		String read = br.readLine();
		while(read != null) {
		    sb.append(read + "\n");
		    read = br.readLine();
		}
		return sb.toString();
	}
}
