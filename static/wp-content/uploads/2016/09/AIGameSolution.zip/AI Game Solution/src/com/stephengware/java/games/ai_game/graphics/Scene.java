package com.stephengware.java.games.ai_game.graphics;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.geom.AffineTransform;
import java.util.ArrayList;
import java.util.PriorityQueue;

import javax.swing.JPanel;

import com.stephengware.java.games.ai_game.Game;
import com.stephengware.java.games.ai_game.Settings;
import com.stephengware.java.games.ai_game.path.Heuristic;
import com.stephengware.java.games.ai_game.path.PathSearch;

/**
 * The visual rendering of the current level.
 * 
 * @author Stephen G. Ware
 */
public class Scene extends JPanel {

	/** Version 1.0 */
	private static final long serialVersionUID = 1L;

	/** The current level object */
	private Level level;
	
	/** The current path search being carried out */
	private PathSearch pathSearch;
	
	/**
	 * Constructs a new scene.
	 * 
	 * @param level the first level to render
	 */
	public Scene(Level level) {
		this.level = level;
		addMouseListener(mouseAdapter);
	}
	
	/**
	 * Changes the current level.
	 * 
	 * @param level the new level to render
	 */
	public void setLevel(Level level) {
		this.level = level;
	}
	
	/**
	 * Sets the current
	 * {@link com.stephengware.java.games.ai_game.path.PathSearch} to
	 * visualize.
	 * 
	 * @param ps the path search object
	 */
	public void setPathSearch(PathSearch ps) {
		this.pathSearch = ps;
	}
	
	/**
	 * Creates a {@link Sprite} at the given X, Y, and Z position in this
	 * level.
	 * 
	 * @param tile the current image the sprite should display
	 * @param x the location on the X axis
	 * @param y the location on the Y axis
	 * @param z the location on the Z axis
	 * @return the newly created sprite
	 */
	public Sprite addSprite(int tile, int x, int y, int z) {
		return level.addSprite(tile, x, y, z);
	}
	
	/**
	 * Returns the player-controlled character sprite.
	 * 
	 * @return the character
	 */
	public Character getCharacter() {
		return level.character;
	}
	
	/**
	 * Returns the sprite currently located at the given X, Y, and Z
	 * coordinates.
	 * 
	 * @param x the location on the X axis
	 * @param y the location on the Y axis
	 * @param z the location on the Z axis
	 * @return the sprite, or null if no sprite exists at those coordinates 
	 */
	public Sprite getSpriteAt(int x, int y, int z) {
		return level.sprites[y * Settings.LEVEL_WIDTH + x][z];
	}
	
	/**
	 * Returns the highest (largest Z value) sprite currently located at the
	 * given X and Y coordinates.
	 * 
	 * @param x the location on the X axis
	 * @param y the location on the Y axis
	 * @return the highest sprite at those X and Y coordinates
	 */
	public Sprite getSpriteAt(int x, int y) {
		for(int z=Level.LEVEL_TOP; z>=0; z--) {
			Sprite sprite = getSpriteAt(x, y, z);
			if(sprite != null)
				return sprite;
		}
		return null;
	}
	
	/**
	 * A structure for tracking a sprite and its distance from a given
	 * location.
	 * 
	 * @author Stephen G. Ware
	 */
	private final class DistanceSprite implements Comparable<DistanceSprite> {
		
		/** The sprite */
		public final Sprite sprite;
		
		/** The sprite's distance from a given location */
		public final int distance;
		
		/**
		 * Constructs a new distance structure.
		 * 
		 * @param sprite the sprite
		 * @param distance the sprite's distance from a given location
		 */
		public DistanceSprite(Sprite sprite, int distance) {
			this.sprite = sprite;
			this.distance = distance;
		}

		@Override
		public int compareTo(DistanceSprite other) {
			return distance - other.distance;
		}
	}
	
	/**
	 * Returns all sprites in the current level that display the given tile.
	 * 
	 * @param tile the tile to search for
	 * @return an iterable collection of all sprites displaying that tile
	 */
	public Iterable<Sprite> getAll(int tile) {
		Character character = getCharacter();
		PriorityQueue<DistanceSprite> queue = new PriorityQueue<>();
		for(int i=0; i<level.sprites.length; i++) {
			for(int j=0; j<level.sprites[i].length; j++) {
				Sprite sprite = level.sprites[i][j];
				if(sprite != null && sprite.getTile() == tile) {
					int distance = Heuristic.evaluate(character, sprite);
					queue.add(new DistanceSprite(sprite, distance));
				}
			}
		}
		ArrayList<Sprite> sprites = new ArrayList<>();
		while(!queue.isEmpty())
			sprites.add(queue.poll().sprite);
		return sprites;
	}
	
	@Override
	@SuppressWarnings("unused")
	public void paintComponent(Graphics g) {
		Graphics2D g2d = (Graphics2D) g;
		AffineTransform t = g2d.getTransform();
		t.scale(Settings.SCALE, Settings.SCALE);
		g2d.setTransform(t);
		g.setColor(Color.black);
		g.fillRect(0, 0, Settings.PANE_SIZE.width, Settings.PANE_SIZE.height);
		for(int z=0; z<level.sprites[0].length; z++)
			for(int i=0; i<level.sprites.length; i++)
				if(level.sprites[i][z] != null)
					level.sprites[i][z].draw(g2d);
		if(Settings.PATH_DEBUG && pathSearch != null)
			pathSearch.draw(g2d);
	}
	
	/**
	 * Detects which sprite the user has clicked on.
	 */
	private final MouseAdapter mouseAdapter = new MouseAdapter() {
		
		@Override
		public void mouseClicked(MouseEvent event) {
			if(Game.console.input.isEnabled()) {
				int x = event.getX() / (Settings.TILE_WIDTH * Settings.SCALE);
				int y = event.getY() / (Settings.TILE_HEIGHT * Settings.SCALE);
				Game.console.parse("WALK " + x + " " + y);
			}
		}
	};
}
