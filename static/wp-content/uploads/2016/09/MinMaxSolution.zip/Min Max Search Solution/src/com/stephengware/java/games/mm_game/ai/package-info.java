/**
 * This package contains the tools needed to build an AI for playing Tic Tac
 * Toe that uses adversarial game tree search techniques.
 */
package com.stephengware.java.games.mm_game.ai;