package com.stephengware.java.games.mm_game.state;

/**
 * The two possible Tic Tac Toe players: X and O.
 * 
 * @author Stephen G. Ware
 */
public enum Player {

	X, O;
}
