package com.stephengware.java.games.ai_game.bt.leaf;

import com.stephengware.java.games.ai_game.Game;
import com.stephengware.java.games.ai_game.Settings;
import com.stephengware.java.games.ai_game.graphics.Character;
import com.stephengware.java.games.ai_game.graphics.Level;
import com.stephengware.java.games.ai_game.graphics.Sprite;
import com.stephengware.java.games.ai_game.graphics.Tiles;

/**
 * If the player has a bomb, a bomb will be placed at the location directly
 * above the player; the bomb will explode; and if there is a door under it
 * that door will be removed.  Returns false if the player does not have a
 * bomb.  The parameter (if any) is ignored.
 * 
 * @author Stephen G. Ware
 */
public class Blast extends Animate {

	/**
	 * Constructs a new instance of the blast behavior.
	 */
	public Blast() {
		super("BLAST", new int[]{Tiles.EXPLOSION_1, Tiles.EXPLOSION_2, Tiles.EXPLOSION_3, Tiles.EXPLOSION_4}, 0, 0);
	}
	
	@Override
	public boolean execute(Sprite argument) {
		return super.execute(null);
	}
	
	@Override
	protected boolean run(Sprite argument) {
		Character character = Game.getCharacter();
		if(character.hasBomb()) {
			character.useBomb();
			Game.getCharacter().setTile(Tiles.FACING_UP);
			pause();
			Game.scene.repaint();
			Sprite above = Game.getCharacter().getAbove();
			Sprite bomb = Game.scene.addSprite(Tiles.BOMB, above.getX(), above.getY(), Level.BOMB_LEVEL);
			Game.scene.repaint();
			pause(Settings.ANIMATION_DELAY * 5);
			super.run(bomb);
			pause();
			bomb.delete();
			Sprite under = Game.getSpriteAt(bomb.getX(), bomb.getY());
			if(under.isDoor() || under.isLock())
				under.delete();
			Game.scene.repaint();
			return true;
		}
		else
			return false;
	}
}
