package com.stephengware.java.games.ai_game.graphics;

import java.awt.image.BufferedImage;
import java.io.IOException;

import javax.imageio.ImageIO;

import com.stephengware.java.games.ai_game.Settings;

/**
 * A tile is an individual image that can be displayed in the graphical
 * rendering of the level.
 * 
 * @author Stephen G. Ware
 */
public class Tiles {
	
	/** An array of all tiles */
	public static final BufferedImage[] TILES = new BufferedImage[36];

	public static final int FACING_DOWN = 0;
	public static final int WALKING_DOWN_1 = 1;
	public static final int WALKING_DOWN_2 = 2;
	public static final int FACING_UP = 3;
	public static final int WALKING_UP_1 = 4;
	public static final int WALKING_UP_2 = 5;
	public static final int FACING_LEFT = 6;
	public static final int WALKING_LEFT_1 = 7;
	public static final int WALKING_LEFT_2 = 8;
	public static final int FACING_RIGHT = 9;
	public static final int WALKING_RIGHT_1 = 10;
	public static final int WALKING_RIGHT_2 = 11;
	public static final int GRASS = 12;
	public static final int FLOOR = 13;
	public static final int PATH = 14;
	public static final int TREE = 15;
	public static final int WOOD_DOOR_CLOSED = 16;
	public static final int WOOD_DOOR_OPEN = 17;
	public static final int METAL_DOOR_CLOSED = 18;
	public static final int METAL_DOOR_OPEN = 19;
	public static final int WALL_FRONT = 20;
	public static final int WALL_SIDE = 21;
	public static final int WALL_BACK = 22;
	public static final int KEY = 23;
	public static final int BOMB = 24;
	public static final int FLASK = 25;
	public static final int EXPLOSION_1 = 26;
	public static final int EXPLOSION_2 = 27;
	public static final int EXPLOSION_3 = 28;
	public static final int EXPLOSION_4 = 29;
	public static final int FRONTIER = 30;
	public static final int ARROW_UP = 31;
	public static final int ARROW_DOWN = 32;
	public static final int ARROW_LEFT = 33;
	public static final int ARROW_RIGHT = 34;
	public static final int ERROR = 35;
	
	/**
	 * Returns true if this tile is the player-controlled character.
	 * 
	 * @param tile the tile to test
	 * @return true if the tile is the character, false otherwise
	 */
	public static final boolean isCharacter(int tile) {
		return tile >= FACING_DOWN && tile <= WALKING_RIGHT_2;
	}
	
	/**
	 * Returns true if this tile is a wall or tree.
	 * 
	 * @param tile the tile to test
	 * @return true if the tile is a wall, false otherwise
	 */
	public static final boolean isWall(int tile) {
		return tile == TREE || (tile >= WALL_FRONT && tile <= WALL_BACK);
	}
	
	/**
	 * Returns true if this tile is a wooden door.
	 * 
	 * @param tile the tile to test
	 * @return true if the tile is a door, false otherwise
	 */
	public static final boolean isDoor(int tile) {
		return tile >= WOOD_DOOR_CLOSED && tile <= WOOD_DOOR_OPEN;
	}
	
	/**
	 * Returns true if this tile is a metal door.
	 * 
	 * @param tile the tile to test
	 * @return true if the tile is a lock, false otherwise
	 */
	public static final boolean isLock(int tile) {
		return tile >= METAL_DOOR_CLOSED && tile <= METAL_DOOR_OPEN;
	}
	
	/**
	 * Returns true if this tile is an item which can be picked up.
	 * 
	 * @param tile the tile to test
	 * @return true if the tile is an item, false otherwise
	 */
	public static final boolean isItem(int tile) {
		return tile == KEY || tile == BOMB || tile == FLASK;
	}
	
	/**
	 * Returns true if this tile blocks the player's movement.
	 * 
	 * @param tile the tile to test
	 * @return true if the tile blocks movement, false otherwise
	 */
	public static final boolean blocksPath(int tile) {
		return isWall(tile) || isDoor(tile) || isLock(tile) || isItem(tile);
	}
	
	/**
	 * Reads all tiles in from a single image, which should be segmented
	 * according to {@link com.stephengware.java.games.ai_game.Settings#TILE_WIDTH}
	 * and {@link com.stephengware.java.games.ai_game.Settings#TILE_HEIGHT}.
	 * 
	 * @throws IOException if an IO error occurs while reading the image
	 */
	public static final void load() throws IOException {
		BufferedImage sheet = ImageIO.read(Tiles.class.getResource(Settings.TILE_SHEET));
		int columns = sheet.getWidth() / Settings.TILE_WIDTH;
		int rows = sheet.getHeight() / Settings.TILE_HEIGHT;
		int index = 0;
		for(int r=0; r<rows; r++) {
			for(int c=0; c<columns; c++) {
				TILES[index] = sheet.getSubimage(c * Settings.TILE_WIDTH, r * Settings.TILE_HEIGHT, Settings.TILE_WIDTH, Settings.TILE_HEIGHT);
				index++;
			}
		}
	}
}
