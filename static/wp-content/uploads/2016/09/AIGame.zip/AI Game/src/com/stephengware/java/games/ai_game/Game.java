package com.stephengware.java.games.ai_game;

import java.awt.GridLayout;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.swing.JOptionPane;
import javax.swing.JPanel;

import com.stephengware.java.games.ai_game.bt.Behaviors;
import com.stephengware.java.games.ai_game.graphics.Character;
import com.stephengware.java.games.ai_game.graphics.Console;
import com.stephengware.java.games.ai_game.graphics.Level;
import com.stephengware.java.games.ai_game.graphics.Scene;
import com.stephengware.java.games.ai_game.graphics.Sprite;
import com.stephengware.java.games.ai_game.graphics.Tiles;

/**
 * This class contains the main GUI and provides access to all other elements
 * of the game, including some of the most important high-level functions.
 * Instances of this class cannot be created; all methods should be accessed
 * statically.
 * 
 * @author Stephen G. Ware
 */
public class Game {

	/** The current level */
	private static int level = Settings.FIRST_LEVEL - 1;
	
	/** The text console */
	public static final Console console = new Console();
	
	/** The graphical rendering of the game world */
	public static final Scene scene = new Scene(Settings.getLevel(level));
	
	/** The main GUI for the whole game */
	static final JPanel gui = new JPanel();

	/**
	 * Loads all elements of the game, including graphical resources and
	 * custom behaviors.
	 * 
	 * @throws IOException if an IO error occurs
	 */
	public static void load() throws IOException {
		Tiles.load();
		Behaviors.load();
		gui.setLayout(new GridLayout(1, 0, 0, 0));
		gui.add(console);
		gui.add(scene);
	}
	
	/**
	 * Returns the player-controlled
	 * {@link com.stephengware.java.games.ai_game.graphics.Character Character}
	 * sprite.
	 * 
	 * @return the character
	 */
	public static Character getCharacter() {
		return scene.getCharacter();
	}
	
	/**
	 * Returns the highest (largest z)
	 * {@link com.stephengware.java.games.ai_game.graphics.Sprite Sprite} at
	 * the given X and Y coordinates in the current level.
	 * 
	 * @param x the X coordinate
	 * @param y the Y coordinate
	 * @return the highest sprite at those coordinates
	 */
	public static Sprite getSpriteAt(int x, int y) {
		return scene.getSpriteAt(x, y);
	}
	
	/** Matches two integers separated by a space */
	private static final Pattern COORDINATE_PATTERN = Pattern.compile("(\\d+)\\s+(\\d+)");
	
	/**
	 * Returns the closest
	 * {@link com.stephengware.java.games.ai_game.graphics.Sprite Sprite} of
	 * a given type to the character.  If the argument is two integers
	 * separated by a space, this methods returns the appropriate value for
	 * {@link #getSpriteAt(int, int)}.  Otherwise, this method returns the
	 * first sprite in the set returned by {@link #find(String)}.
	 * 
	 * @param argument the type of sprite to search for or a location
	 * @return the closest sprite
	 */
	public static Sprite find(String argument) {
		Matcher matcher = COORDINATE_PATTERN.matcher(argument);
		if(matcher.find())
			return getSpriteAt(Integer.parseInt(matcher.group(1)), Integer.parseInt(matcher.group(2)));
		Iterator<Sprite> all = getAll(argument).iterator();
		if(all.hasNext())
			return all.next();
		throw new IllegalArgumentException("Argument \"" + argument + "\" not recongized.");
	}
	
	/**
	 * Returns all
	 * {@link com.stephengware.java.games.ai_game.graphics.Sprite Sprite}s
	 * in the current level that match a given type string, such as 'KEY',
	 * 'BOMB', etc.
	 * 
	 * @param argument the type of sprite to return
	 * @return all such sprites in the current level
	 */
	public static Iterable<Sprite> getAll(String argument) {
		argument = argument.toUpperCase();
		int tile;
		switch(argument) {
		case "KEY": tile = Tiles.KEY; break;
		case "BOMB": tile = Tiles.BOMB; break;
		case "DOOR": tile = Tiles.WOOD_DOOR_CLOSED; break;
		case "LOCK": tile = Tiles.METAL_DOOR_CLOSED; break;
		case "FLASK": tile = Tiles.FLASK; break;
		default: tile = -1;
		}
		if(tile == -1)
			throw new IllegalArgumentException("Argument \"" + argument + "\" not recongized.");
		ArrayList<Sprite> all = new ArrayList<>();
		scene.getAll(tile).forEach((Sprite sprite) -> { all.add(sprite.getBelow()); });
		return all;
	}
	
	/**
	 * Loads the next level, or displays a victory message if there are no more
	 * levels.
	 */
	public static void advanceLevel() {
		new LevelAdvancer(Thread.currentThread()).start();
	}
	
	/**
	 * Used to advance the level only after the currently executing thread has
	 * finished.
	 * 
	 * @author Stephen G. Ware
	 */
	private static final class LevelAdvancer extends Thread {
		
		/** The currently executing thread */
		private final Thread toJoin;
		
		/**
		 * Constructs a new LevelAdvancer thread.
		 * 
		 * @param toJoin the currently executing thread
		 */
		public LevelAdvancer(Thread toJoin) {
			this.toJoin = toJoin;
		}
		
		@Override
		public void run() {
			try {
				toJoin.join();
			}
			catch(InterruptedException e) {
				e.printStackTrace();
			}
			level++;
			Level next = Settings.getLevel(level);
			if(next == null) {
				JOptionPane.showMessageDialog(null, "You have won!", "Victory", JOptionPane.PLAIN_MESSAGE);
				System.exit(0);
			}
			else {
				Game.console.append("\nLevel " + level);
				scene.setLevel(next);
				scene.repaint();
			}
		}
	}
	
	/**
	 * A private constructor ensures that instances of this object cannot be
	 * created.
	 */
	private Game() {}
}
