package com.stephengware.java.games.ai_game.bt;

/**
 * A composite is an internal node with an arbitrary number children.
 * 
 * @author Stephen G. Ware
 */
public abstract class Composite extends BehaviorTree {

	/** The children behaviors of this behavior */
	protected final BehaviorTree[] children;
	
	/**
	 * Constructs a new composite with a given name and with the given
	 * children.
	 * 
	 * @param name the name of the behavior
	 * @param children the children behaviors
	 */
	public Composite(String name, BehaviorTree...children) {
		super(name);
		for(BehaviorTree child : children)
			if(child == null)
				throw new IllegalArgumentException("Null children not allowed");
		this.children = children;
	}
}
