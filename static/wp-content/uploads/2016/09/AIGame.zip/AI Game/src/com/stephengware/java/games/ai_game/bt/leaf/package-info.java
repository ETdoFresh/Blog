/**
 * Contains the leaf nodes available for use in behavior trees.
 */
package com.stephengware.java.games.ai_game.bt.leaf;