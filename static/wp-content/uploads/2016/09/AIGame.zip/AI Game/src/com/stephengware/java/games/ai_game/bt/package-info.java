/**
 * Contains the logic for implementing simple parameterized behavior trees.
 */
package com.stephengware.java.games.ai_game.bt;