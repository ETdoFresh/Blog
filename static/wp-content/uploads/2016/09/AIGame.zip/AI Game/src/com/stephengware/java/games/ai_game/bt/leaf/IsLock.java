package com.stephengware.java.games.ai_game.bt.leaf;

import com.stephengware.java.games.ai_game.bt.Leaf;
import com.stephengware.java.games.ai_game.graphics.Sprite;

/**
 * Returns true if the parameter is a closed metal door.
 * 
 * @author Stephen G. Ware
 */
public class IsLock extends Leaf {

	/**
	 * Constructs a new instance of the is lock behavior.
	 */
	public IsLock() {
		super("IS_LOCK");
	}

	@Override
	protected boolean run(Sprite argument) {
		if(argument == null)
			return false;
		else
			return argument.getAbove().isLock();
	}
}
