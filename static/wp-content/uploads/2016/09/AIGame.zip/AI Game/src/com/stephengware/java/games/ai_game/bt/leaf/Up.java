package com.stephengware.java.games.ai_game.bt.leaf;

import com.stephengware.java.games.ai_game.Game;
import com.stephengware.java.games.ai_game.graphics.Sprite;
import com.stephengware.java.games.ai_game.graphics.Tiles;

/**
 * The player moves one grid square upwards.  Returns false if that square is
 * blocked by an object.  The parameter (if any) is ignored.
 * 
 * @author Stephen G. Ware
 */
public class Up extends Animate {

	/**
	 * Constructs a new instance of the up behavior.
	 */
	public Up() {
		super("UP", new int[]{Tiles.WALKING_UP_1, Tiles.WALKING_UP_2, Tiles.FACING_UP}, 0, -1);
	}
	
	@Override
	public boolean execute(Sprite argument) {
		return super.execute(null);
	}
	
	@Override
	public boolean run(Sprite argument) {
		if(Game.getCharacter().getAbove().blocksPath())
			return false;
		else
			return super.run(Game.getCharacter());
	}
}
