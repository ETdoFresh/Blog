package com.stephengware.java.games.ai_game.bt.leaf;

import com.stephengware.java.games.ai_game.Game;
import com.stephengware.java.games.ai_game.Settings;
import com.stephengware.java.games.ai_game.bt.Leaf;
import com.stephengware.java.games.ai_game.graphics.Character;
import com.stephengware.java.games.ai_game.graphics.Sprite;
import com.stephengware.java.games.ai_game.graphics.Tiles;

/**
 * If there is an item directly above the player, that item is picked up and
 * removed from the screen and this behavior returns true.  This behavior
 * returns false otherwise.  The parameter (if any) is ignored.
 * 
 * @author Stephen G. Ware
 */
public class Take extends Leaf {

	/**
	 * Constructs a new instance of the take behavior.
	 */
	public Take() {
		super("TAKE");
	}
	
	@Override
	public boolean execute(Sprite argument) {
		return super.execute(null);
	}

	@Override
	protected boolean run(Sprite argument) {
		Character character = Game.getCharacter();
		Sprite above = character.getAbove();
		if(above.isItem()) {
			character.setTile(Tiles.FACING_UP);
			if(above.getTile() == Tiles.KEY) {
				character.getKey();
				above.delete();
			}
			else if(above.getTile() == Tiles.BOMB) {
				character.getBomb();
				above.delete();
			}
			else if(above.getTile() == Tiles.FLASK) {
				above.delete();
				Game.advanceLevel();
			}
			Game.scene.repaint();
			Animate.pause(Settings.ANIMATION_DELAY * 3);
			return true;
		}
		else
			return false;
	}
}
