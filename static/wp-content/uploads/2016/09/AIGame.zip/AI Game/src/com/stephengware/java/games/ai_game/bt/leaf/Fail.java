package com.stephengware.java.games.ai_game.bt.leaf;

import com.stephengware.java.games.ai_game.bt.Leaf;
import com.stephengware.java.games.ai_game.graphics.Sprite;

/**
 * Always returns false.
 * 
 * @author Stephen G. Ware
 */
public class Fail extends Leaf {

	/**
	 * Constructs a new instance of the fail behavior.
	 */
	public Fail() {
		super("FAIL");
	}
	
	@Override
	public boolean execute(Sprite argument) {
		return super.execute(null);
	}

	@Override
	protected boolean run(Sprite argument) {
		return false;
	}
}
