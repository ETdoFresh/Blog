package com.stephengware.java.games.ai_game.bt;

import com.stephengware.java.games.ai_game.graphics.Sprite;

/**
 * A selector is a composite which will run each of its children in order
 * until one of them returns true and then this behavior returns true.  If no
 * child returns true, this behavior returns false.
 * 
 * @author Stephen G. Ware
 */
public class Selector extends Composite {

	/**
	 * Constructs a new selector with the given children.
	 * 
	 * @param children the children behaviors
	 */
	public Selector(BehaviorTree...children) {
		super("SELECTOR", children);
	}

	@Override
	protected boolean run(Sprite argument) {
		for(BehaviorTree child : children)
			if(child.execute(argument))
				return true;
		return false;
	}
}
