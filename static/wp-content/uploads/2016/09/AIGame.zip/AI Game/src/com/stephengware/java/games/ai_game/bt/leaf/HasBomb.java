package com.stephengware.java.games.ai_game.bt.leaf;

import com.stephengware.java.games.ai_game.Game;
import com.stephengware.java.games.ai_game.bt.Leaf;
import com.stephengware.java.games.ai_game.graphics.Sprite;

/**
 * Returns true if the player has one or more bombs, false otherwise.  The
 * parameter (if any) is ignored.
 * 
 * @author Stephen G. Ware
 */
public class HasBomb extends Leaf {

	/**
	 * Constructs a new instance of the has bomb behavior.
	 */
	public HasBomb() {
		super("HAS_BOMB");
	}
	
	@Override
	public boolean execute(Sprite argument) {
		return super.execute(null);
	}

	@Override
	protected boolean run(Sprite argument) {
		return Game.getCharacter().hasBomb();
	}
}
