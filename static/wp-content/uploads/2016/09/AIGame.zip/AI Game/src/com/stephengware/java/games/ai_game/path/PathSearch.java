package com.stephengware.java.games.ai_game.path;

import java.awt.Graphics2D;

import com.stephengware.java.games.ai_game.Game;
import com.stephengware.java.games.ai_game.Settings;
import com.stephengware.java.games.ai_game.bt.Behaviors;
import com.stephengware.java.games.ai_game.graphics.Sprite;
import com.stephengware.java.games.ai_game.graphics.Tiles;

/**
 * Represents the process of intelligently finding a path between two locations
 * using the A* algorithm.  Search occurs only along the X and Y axes and
 * ignores the Z axis.
 * 
 * @author Your Name
 */
public class PathSearch {

	/** The location at which the path starts */
	public final Sprite origin;
	
	/** The location at which the path ends */
	public final Sprite destination;
	
	/**
	 * For a given X and Y location, this array stores the location of the
	 * previous step in the path.  For example, if one step in the path goes
	 * from location (3,5) to location (4,5), then history[4,5] = (3,5).
	 * This array is used to retrace the path once a solution is found.
	 * It should be accessed as history[x][y].
	 */
	private final Sprite[][] history = new Sprite[Settings.LEVEL_WIDTH][Settings.LEVEL_HEIGHT];
	
	/**
	 * For a given X and Y location, this array stores the total distance
	 * traveled by the time the search has reached that location.  For example,
	 * if the search has traveled 4 steps by the time it reaches (3,5), then
	 * distance[3][5] = 4.  It should be accessed as distance[x][y].
	 */
	private final int[][] distance = new int[Settings.LEVEL_WIDTH][Settings.LEVEL_HEIGHT];
	
	/** Stores the locations on the boundary of the search */
	private final PriorityQueue frontier = new PriorityQueue();
	
	/**
	 * Creates a new search from a given origin to a given destination.
	 * 
	 * @param origin the start of the search
	 * @param destination the location of the search
	 */
	public PathSearch(Sprite origin, Sprite destination) {
		this.origin = origin;
		this.destination = destination;
	}
	
	/**
	 * Performs the search and indicates whether or not it was successful.
	 * 
	 * @return the length of the path if one was found, or -1 if no path was
	 * found
	 */
	public int search() {
		// === Step 3 ===
		// The search begins at the origin, so the origin needs to be the first
		// location on the frontier.  Because the path starts at the origin,
		// its distance traveled so far is 0.  Use Heuristic#evaluate to
		// estimate the distance between the origin and the destination.
		
		// The search should running until a path is found or until there is
		// nowhere left to search.
		
		// An iteration of the search begins by removing the a point from the
		// frontier.
		Sprite current;
		// If that point is the destination, a path has been found.  Return the
		// length of the path.
		
		// If that point is not the destination, we need to expand the frontier
		// by considering all the possible next steps on the path.  For this
		// game, the character can only move up, down, left, and right.
		// Consider each of these next steps in turn by calling
		// PathSearch#consider.
		
		// If every possible path has been considered and no solution was
		// found, return -1.
		return -1;
	}
	
	/**
	 * Checks whether or not a given step should be considered during the
	 * search.  A step means moving from one location (called 'current') to a
	 * next location (called 'next').  'Next' should be reachable from
	 * 'current' by exactly one up, down, left, or right step.
	 * 
	 * @param current the location to step away from
	 * @param next the location to step to
	 */
	private void consider(Sprite current, Sprite next) {
		// === Step 4 ===
		// If the next location has already been considered as part of some
		// other path, do not consider it again.  We know that a location has
		// been considered if it has an entry in the history array.
		// Also, do not consider any locations which are blocked by walls or
		// other objects.  You can test this using Sprite#blocksPath.
		
		// If 'next' passes the two tests described above, then it is a valid
		// next place to walk to on the path.  Mark this location as visited
		// by putting a value into the history array.  The value you put into
		// the history array should be the location you just left to get to
		// 'next'.  By storing the previous location in the history array, we
		// will be able to reconstruct the path if a solution is found.
		
		// Calculate the total distance traveled so far on this path.  This is
		// simply the distance traveled to get to 'current' + 1.  The distance
		// array stores the distances traveled, so you can use that to look up
		// the distance traveled to 'current'.  You should also update that
		// array to include the distance traveled to 'next'.
		int dist;
		// Add the new location to the frontier of the search.  When adding it,
		// make sure to include the distance traveled to reach the new location
		// and an estimate of how far the new location is from the destination.
		// Use PriorityQueue#push for this.
		
	}
	
	/**
	 * Causes the player-controlled character to walk the path discovered
	 * during this search.  This method should only be called after
	 * {@link #search()}, and only if {@link #search()} did not return -1.
	 */
	public void walk() {
		// === Step 5 ===
		// This method uses the recursive helper method PathSearch#walkTo to
		// reconstruct the solution path backwards from the destination.
		
	}
	
	/**
	 * This recursive helper method is used to reconstruct a path backwards.
	 * 
	 * @param location the location to walk to
	 */
	private void walkTo(Sprite location) {
		// === Step 6 ===
		// If the location in question is the origin, then this method is
		// finished and no more steps need to be taken (because the
		// character starts at the origin).
		
		// Otherwise, we need to take one or more steps to reach the location
		// in question.  The history array keeps track of the location the
		// character needs to be standing immediately before walking to
		// 'location'.  Look up that location in the history array.
		Sprite previous;
		// Before we can take the current step on the path, the character needs
		// to be at that previous location.  Ensure this with a recursive call
		// to this method.
		
		// Now the character is standing at 'previous' and we need to make him
		// take a single step to reach 'location'.  The options are up, down,
		// left, and right.  Determine which direction to walk and tell the
		// character to walk using (for example) Behavior#execute("UP").
		
	}
	
	/**
	 * Draws the current state of the path search on top of the game for
	 * debugging purposes.
	 * 
	 * @param g the graphics context on which to draw
	 */
	public void draw(Graphics2D g) {
		for(int x=0; x<history.length; x++) {
			for(int y=0; y<history[x].length; y++) {
				Sprite h = history[x][y];
				if(h != null) {
					Sprite sprite = Game.getSpriteAt(x, y);
					int arrow = Tiles.ERROR;
					if(h.getAbove() == sprite)
						arrow = Tiles.ARROW_DOWN;
					else if(h.getBelow() == sprite)
						arrow = Tiles.ARROW_UP;
					else if(h.getLeft() == sprite)
						arrow = Tiles.ARROW_RIGHT;
					else if(h.getRight() == sprite)
						arrow = Tiles.ARROW_LEFT;
					g.drawImage(Tiles.TILES[arrow], x * Settings.TILE_WIDTH, y * Settings.TILE_HEIGHT, null);
				}
			}
		}
	}
}
