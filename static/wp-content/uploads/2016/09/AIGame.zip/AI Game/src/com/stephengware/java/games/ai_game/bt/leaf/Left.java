package com.stephengware.java.games.ai_game.bt.leaf;

import com.stephengware.java.games.ai_game.Game;
import com.stephengware.java.games.ai_game.graphics.Sprite;
import com.stephengware.java.games.ai_game.graphics.Tiles;

/**
 * The player moves one grid square to the left.  Returns false if that square
 * is blocked by an object.  The parameter (if any) is ignored.
 * 
 * @author Stephen G. Ware
 */
public class Left extends Animate {

	/**
	 * Constructs a new instance of the left behavior.
	 */
	public Left() {
		super("LEFT", new int[]{Tiles.WALKING_LEFT_1, Tiles.WALKING_LEFT_2, Tiles.FACING_LEFT}, -1, 0);
	}
	
	@Override
	public boolean execute(Sprite argument) {
		return super.execute(null);
	}
	
	@Override
	public boolean run(Sprite argument) {
		if(Game.getCharacter().getLeft().blocksPath())
			return false;
		else
			return super.run(Game.getCharacter());
	}
}
