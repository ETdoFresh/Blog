package com.stephengware.java.games.ai_game.bt;

import com.stephengware.java.games.ai_game.graphics.Sprite;

/**
 * A root has 1 child and no parent and is provided here as a placeholder for
 * the parsing of custom-defined behavior trees.
 * 
 * @author Stephen G. Ware
 */
public class Root extends BehaviorTree {

	/** The behavior to execute when this behavior is executed */
	BehaviorTree child;
	
	/**
	 * Constructs a new behavior with a given name.
	 * 
	 * @param name the name of this behavior
	 */
	public Root(String name) {
		super(name);
	}

	@Override
	protected boolean run(Sprite argument) {
		return child.execute(argument);
	}
}
