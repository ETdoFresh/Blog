package com.stephengware.java.games.ai_game.bt;

import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedHashMap;

import com.stephengware.java.games.ai_game.Game;
import com.stephengware.java.games.ai_game.Utilities;
import com.stephengware.java.games.ai_game.bt.leaf.*;

/**
 * A statically-accessed class that stores all the pre-defined and custom
 * behaviors in the game.
 * 
 * @author Stephen G. Ware
 */
public class Behaviors {
	
	/**
	 * Executes a given behavior and passes it the given argument.
	 * 
	 * @param verb the behavior to execute
	 * @param noun the argument to pass the behavior
	 * @return true if the behavior succeeded, false otherwise
	 */
	public static boolean execute(String verb, String noun) {
		verb = verb.toUpperCase();
		if(noun == null)
			return get(verb).execute(null);
		else
			return get(verb).execute(Game.find(noun.toUpperCase()));
	}
	
	/**
	 * Executes a given behavior with no argument.
	 * 
	 * @param behavior the behavior to execute
	 * @return true if the behavior succeeded, false otherwise
	 */
	public static boolean execute(String behavior) {
		return execute(behavior, null);
	}
	
	/** Stores all the behaviors indexed by name */
	private static final LinkedHashMap<String, BehaviorTree> behaviors = new LinkedHashMap<>();
	
	/**
	 * Adds a new behavior to the set of available behaviors.
	 * 
	 * @param behavior the new behavior
	 */
	private static void add(BehaviorTree behavior) {
		behaviors.put(behavior.name, behavior);
	}
	
	/**
	 * Returns a behavior with the given name.
	 * 
	 * @param name the name of the behavior
	 * @return the behavior with that name
	 * @throws IllegalArgumentException if no such behavior exists
	 */
	private static BehaviorTree get(String name) {
		BehaviorTree behavior = behaviors.get(name);
		if(behavior == null)
			throw new IllegalArgumentException("Behavior \"" + name + "\" not defined.");
		else
			return behavior;
	}
	
	/**
	 * Parse a set of custom-defined behavior trees.
	 * 
	 * @param text the text defining the behavior tree
	 */
	private static void parse(String text) {
		String[] lines = text.toUpperCase().split("\\n");
		for(int i=0; i<lines.length; i++) {
			if(definesNewTree(lines[i])) {
				lines[i] = lines[i].trim();
				add(new Root(lines[i]));
			}
		}
		for(int i=0; i<lines.length; i++)
			if(definesNewTree(lines[i]))
				((Root) get(lines[i])).child = parse(lines, i + 1, 1);
	}
	
	/**
	 * Returns true if the given line marks the start of a new behavior tree.
	 * 
	 * @param line the line in question
	 * @return true of this line starts a new behavior tree, false otherwise
	 */
	private static boolean definesNewTree(String line) {
		return !line.isEmpty() && !line.startsWith("|") && !line.trim().contains(" ");
	}
	
	/**
	 * Parse a single custom-defined behavior tree, including any child nodes.
	 * 
	 * @param lines the lines of text defining the tree
	 * @param i the line on which this tree begins
	 * @param depth the depth of this tree (distance from the root)
	 * @return the behavior tree defined by this text
	 */
	private static BehaviorTree parse(String[] lines, int i, int depth) {
		if(lines[i].trim().isEmpty())
			return get("FAIL");
		ArrayList<BehaviorTree> childrenList = new ArrayList<>();
		for(int j=i+1; j<lines.length; j++) {
			String line = lines[j];
			int d = 0;
			while(line.startsWith("| ")) {
				line = line.substring(2);
				d++;
			}
			if(d == depth + 1)
				childrenList.add(parse(lines, j, depth + 1));
			else if(d == depth)
				break;
		}
		BehaviorTree[] children = childrenList.toArray(new BehaviorTree[childrenList.size()]);
		String name = lines[i].substring(depth * 2);
		switch(name) {
		case "SEQUENCE": return new Sequence(children);
		case "SELECTOR": return new Selector(children);
		case "INVERTER": return new Inverter(children);
		case "REPEATER": return new Repeater(children);
		}
		if(name.startsWith("EACH_") || name.startsWith("ANY_")) {
			String type = name.substring(name.indexOf("_") + 1);
			if(name.startsWith("EACH"))
				return new Each(type, children);
			else if(name.startsWith("ANY"))
				return new Any(type, children);
		}
		return get(name);
	}
	
	/**
	 * Loads all pre-defined behavior trees and attempts to parse the
	 * custom-defined behavior trees.
	 * 
	 * @throws IOException if an IO error occurs when reading the
	 * custom-defined behavior trees
	 */
	public static void load() throws IOException {
		add(new Fail());
		add(new HasBomb());
		add(new HasKey());
		add(new IsDoor());
		add(new IsLock());
		add(new Up());
		add(new Down());
		add(new Left());
		add(new Right());
		add(new Walk());
		add(new Take());
		add(new Open());
		add(new Unlock());
		add(new Blast());
		parse(Utilities.getResourceAsString("behaviors.txt"));
	}
	
	/**
	 * Returns a list describing the custom-defined behavior trees.
	 * 
	 * @return a string describing the custom behaviors
	 */
	public static String getCustomBehaviors() {
		String custom = "";
		String line = "Custom Verbs: ";
		boolean first = true;
		for(BehaviorTree tree : behaviors.values()) {
			if(tree instanceof Root) {
				if(first)
					first = false;
				else
					line += ", ";
				if((line + tree.name).length() > 62) {
					custom += line + "\n";
					line = "";
				}
				line += tree.name;
			}
		}
		return custom + line;
	}
	
	/**
	 * Private constructor prevents instances of this object from being
	 * created.
	 */
	private Behaviors() {}
}
