package com.stephengware.java.games.ai_game.bt.leaf;

import com.stephengware.java.games.ai_game.Game;
import com.stephengware.java.games.ai_game.Settings;
import com.stephengware.java.games.ai_game.bt.Leaf;
import com.stephengware.java.games.ai_game.graphics.Character;
import com.stephengware.java.games.ai_game.graphics.Sprite;
import com.stephengware.java.games.ai_game.graphics.Tiles;

/**
 * If there is a closed metal door directly above the player and the player
 * has a key, the door is converted into a closed wooden door and this
 * behavior returns true.  Otherwise this behavior returns false.  The
 * parameter (if any) is ignored.
 * 
 * @author Stephen G. Ware
 */
public class Unlock extends Leaf {

	/**
	 * Constructs a new instance of the unlock behavior.
	 */
	public Unlock() {
		super("UNLOCK");
	}
	
	@Override
	public boolean execute(Sprite argument) {
		return super.execute(null);
	}

	@Override
	protected boolean run(Sprite argument) {
		Character character = Game.getCharacter();
		Sprite above = character.getAbove();
		if(above.getTile() == Tiles.METAL_DOOR_CLOSED && character.hasKey()) {
			character.useKey();
			character.setTile(Tiles.FACING_UP);
			above.setTile(Tiles.WOOD_DOOR_CLOSED);
			Game.scene.repaint();
			Animate.pause(Settings.ANIMATION_DELAY * 2);
			return true;
		}
		else
			return false;
	}
}
