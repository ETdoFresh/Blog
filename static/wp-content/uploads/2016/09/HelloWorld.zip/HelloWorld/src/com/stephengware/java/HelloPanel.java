package com.stephengware.java;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;

import javax.swing.JPanel;

public class HelloPanel extends JPanel {

	private static final long serialVersionUID = 1L;

	public HelloPanel() {
		setPreferredSize(new Dimension(200, 100));
	}
	
	@Override
	public void paintComponent(Graphics g) {
		g.setColor(Color.WHITE);
		g.fillRect(0, 0, getWidth(), getHeight());
		g.setColor(Color.BLACK);
		g.drawString("Hello World", 5, 50);
	}
}
