package com.stephengware.java;
import java.awt.BorderLayout;

import javax.swing.JFrame;

public class HelloFrame extends JFrame {

	private static final long serialVersionUID = 1L;

	public HelloFrame() {
		setTitle("Hello World");
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		getContentPane().setLayout(new BorderLayout());
		getContentPane().add(new HelloPanel(), BorderLayout.CENTER);
		pack();
		setLocationRelativeTo(null);
		setVisible(true);
	}
	
	public static void main(String[] args) {
		new HelloFrame();
	}
}
