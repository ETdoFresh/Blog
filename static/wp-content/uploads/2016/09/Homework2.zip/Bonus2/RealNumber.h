#pragma once
#include <iostream>
#include <string>
using namespace std;

// RealNumber
// A number (float) that has no imaginary components
// Does not contain a factor of sqrt(-1)
class RealNumber
{
public:
	RealNumber(float newA = 0);
	RealNumber(const RealNumber & other); // copy constructor
	~RealNumber();
	float GetA() const;

	RealNumber operator+(const RealNumber & other);
	RealNumber operator-(const RealNumber & other);
	RealNumber operator/(const RealNumber & other);
	RealNumber operator*(const RealNumber & other);
	bool operator==(const RealNumber & other);

	virtual string ToString();

protected:
	float a;
};

ostream & operator << (ostream& os, RealNumber& realNumber);
