#include "ComplexNumber.h"

ComplexNumber::ComplexNumber(float newA, float newB)
{
	a = newA;
	b = newB;
}

ComplexNumber::ComplexNumber(const ComplexNumber & other)
{
	a = other.a;
	b = other.b;
}

ComplexNumber::~ComplexNumber()
{
}

float ComplexNumber::GetB() const
{
	return b;
}

ComplexNumber ComplexNumber::operator+(const RealNumber & other)
{
	return ComplexNumber(a + other.GetA(), b);
}

ComplexNumber ComplexNumber::operator-(const RealNumber & other)
{
	return ComplexNumber(a - other.GetA(), b);
}

ComplexNumber ComplexNumber::operator/(const RealNumber & other)
{
	return ComplexNumber(a / other.GetA(), b / other.GetA());
}

ComplexNumber ComplexNumber::operator*(const RealNumber & other)
{
	return ComplexNumber(a * other.GetA(), b * other.GetA());
}

bool ComplexNumber::operator==(const ComplexNumber & other)
{
	// Converting to RealNumber to use == with Epsilon Error
	return RealNumber(a) == RealNumber(other.a) && RealNumber(b) == RealNumber(other.b);
}

ComplexNumber ComplexNumber::operator+(const ComplexNumber & other)
{
	return ComplexNumber(a + other.a, b + other.b);
}

ComplexNumber ComplexNumber::operator-(const ComplexNumber & other)
{
	return ComplexNumber(a - other.a, b - other.b);
}

ComplexNumber ComplexNumber::operator/(const ComplexNumber & other)
{
	float c = other.a;
	float d = other.b;
	float newA = (a * c + b * d) / (c * c + d * d);
	float newB = (b * c - a * d) / (c * c + d * d);
	return ComplexNumber(newA, newB);
}

ComplexNumber ComplexNumber::operator*(const ComplexNumber & other)
{
	float c = other.a;
	float d = other.b;
	float newA = (a * c - b * d);
	float newB = (b * c + a * d);
	return ComplexNumber(newA, newB);
}

bool ComplexNumber::operator==(const RealNumber & other)
{
	// Converting to RealNumber to use == with Epsilon Error
	return RealNumber(a) == RealNumber(other.GetA()) && RealNumber(b) == RealNumber(0);
}

string ComplexNumber::ToString()
{
	string aStr = RealNumber::ToString();
	char bStr[16];
	snprintf(bStr, 16, "%.6g", a);
	string str = aStr + " + " + bStr + "i";
	return str;
}
