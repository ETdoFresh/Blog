#pragma once
#include "RealNumber.h"
using namespace std;

// ComplexNumber
// A number that is represented in the form a + bi
// Where a and b are real numbers and i^2 = -1
class ComplexNumber : public RealNumber
{
public:
	ComplexNumber(float newA = 0, float newB = 0);
	ComplexNumber(const ComplexNumber & other); // copy constructor
	~ComplexNumber();
	float GetB() const;
	
	ComplexNumber operator+(const RealNumber & other);
	ComplexNumber operator-(const RealNumber & other);
	ComplexNumber operator/(const RealNumber & other);
	ComplexNumber operator*(const RealNumber & other);
	bool operator==(const RealNumber & other);

	ComplexNumber operator+(const ComplexNumber & other);
	ComplexNumber operator-(const ComplexNumber & other);
	ComplexNumber operator/(const ComplexNumber & other);
	ComplexNumber operator*(const ComplexNumber & other);
	bool operator==(const ComplexNumber & other);
	
	virtual string ToString();

protected:
	float b;
};
