// BONUS 2: Complex Number Test
//
// Can code duplication be reduced by using inheritance and having a common abstract
// superclass and / or interface ? Implement and test this....
//
// It's a bit too late now, but after talking to classmates, I realized it makes much
// more sense that RealNumber extend ComplexNumber instead of the other way around. But...
// I probably learned more about C++ this way.

#include <iostream>
#include "ComplexNumber.h"
using namespace std;

#define FLT_MIN 1.175494e-38
#define FLT_MAX 3.402823e+38

float RandomFloat(float min = 0, float max = 1);
void TestConstructors();
void TestGetters();
void TestOperators();

int main(int argc, char* argv[])
{
	TestConstructors();
	TestGetters();
	TestOperators();
	cin.get();
	return 0;
}

RealNumber realNumbers[] = {
	RealNumber(0.0000001f),
	RealNumber(RandomFloat()),
	RealNumber(RandomFloat(-99999,99999)),
};

ComplexNumber complexNumbers[] = {
	ComplexNumber(),
	ComplexNumber(RandomFloat(),RandomFloat()),
	ComplexNumber(RandomFloat(-99999,99999),RandomFloat(-99999,99999)),
};

float RandomFloat(float min, float max)
{
	float range = max - min;
	return ((float(rand()) / float(RAND_MAX)) * range) + min;
}

void TestConstructors()
{
	cout << "Testing Constructors" << endl;
	cout << "--------------------" << endl;
	for (RealNumber realNumber : realNumbers)
		cout << realNumber << endl;
	for (ComplexNumber complexNumber : complexNumbers)
		cout << complexNumber << endl;
	cout << endl;
}

void TestGetters()
{
	cout << "Testing Getters" << endl;
	cout << "--------------------" << endl;
	for (RealNumber realNumber : realNumbers)
		cout << realNumber.GetA() << endl;
	for (ComplexNumber complexNumber : complexNumbers)
	{
		RealNumber rA = complexNumber.GetA();
		RealNumber rB = complexNumber.GetB();
		cout << rA << " " << rB << endl;
	}
	cout << endl;
}

void TestOperators()
{
	cout << "Testing Arithmetic" << endl;
	cout << "--------------------" << endl;
	for (ComplexNumber complexNumber1 : complexNumbers)
	{
		for (ComplexNumber complexNumber2 : complexNumbers)
		{
			ComplexNumber result = complexNumber1 + complexNumber2;
			cout << "(" << complexNumber1 << ") + (" << complexNumber2 << ") = ";
			cout << result << endl;

			result = complexNumber1 - complexNumber2;
			cout << "(" << complexNumber1 << ") - (" << complexNumber2 << ") = ";
			cout << result << endl;

			result = complexNumber1 * complexNumber2;
			cout << "(" << complexNumber1 << ") * (" << complexNumber2 << ") = ";
			cout << result << endl;

			result = complexNumber1 / complexNumber2;
			cout << "(" << complexNumber1 << ") / (" << complexNumber2 << ") = ";
			cout << result << endl;

			bool resultBool = complexNumber1 == complexNumber2;
			cout << "(" << complexNumber1 << ") == (" << complexNumber2 << ") = ";
			cout << resultBool << endl;
		}
		for (RealNumber realNumber : realNumbers)
		{
			ComplexNumber result = complexNumber1 + realNumber;
			cout << "(" << complexNumber1 << ") + (" << realNumber << ") = ";
			cout << result << endl;

			result = complexNumber1 - realNumber;
			cout << "(" << complexNumber1 << ") - (" << realNumber << ") = ";
			cout << result << endl;

			result = complexNumber1 * realNumber;
			cout << "(" << complexNumber1 << ") * (" << realNumber << ") = ";
			cout << result << endl;

			result = complexNumber1 / realNumber;
			cout << "(" << complexNumber1 << ") / (" << realNumber << ") = ";
			cout << result << endl;

			bool resultBool = complexNumber1 == realNumber;
			cout << "(" << complexNumber1 << ") == (" << realNumber << ") = ";
			cout << resultBool << endl;
		}
	}
	cout << endl;
}