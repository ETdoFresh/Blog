# Homework Two - Class ComplexNumber
This project was built using Visual Studio 2015 in Windows.

To compile with Visual Studio
- Open Homework2.sln in Visual Studio
- Right-Click Project you want to Compile
- Select "Set as StartUp Project"
- Click Play/Local Windows Debugger

To compile with G++/Make
- In a terminal, navigate to ./Homework2/{DesiredProject} (ie Homework2/Bonus1/Bonus2)
- Run "make" (This will output an executable)
- Run {DesiredProject}