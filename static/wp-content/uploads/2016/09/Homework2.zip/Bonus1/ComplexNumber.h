#pragma once
#include "RealNumber.h"
using namespace std;

// ComplexNumber
// A number that is represented in the form a + bi
// Where a and b are real numbers and i^2 = -1
class ComplexNumber
{
public:
	ComplexNumber();
	ComplexNumber(RealNumber newA, RealNumber newB);
	ComplexNumber(const ComplexNumber & other); // copy constructor
	~ComplexNumber();
	RealNumber GetA() const;
	RealNumber GetB() const;

	ComplexNumber operator+(const ComplexNumber & other);
	ComplexNumber operator-(const ComplexNumber & other);
	ComplexNumber operator/(const ComplexNumber & other);
	ComplexNumber operator*(const ComplexNumber & other);
	bool operator==(const ComplexNumber & other);

	ComplexNumber operator+(RealNumber & other);
	ComplexNumber operator-(RealNumber & other);
	ComplexNumber operator/(RealNumber & other);
	ComplexNumber operator*(RealNumber & other);
	bool operator==(const RealNumber & other);

protected:
	RealNumber a;
	RealNumber b;
};

ostream & operator<<(ostream & os, ComplexNumber & complexNumber);