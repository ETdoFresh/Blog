#include "ComplexNumber.h"

ComplexNumber::ComplexNumber()
{
	a = 0;
	b = 0;
}

ComplexNumber::ComplexNumber(RealNumber newA, RealNumber newB)
{
	a = newA;
	b = newB;
}

ComplexNumber::ComplexNumber(const ComplexNumber & other)
{
	a = other.a;
	b = other.b;
}

ComplexNumber::~ComplexNumber()
{
}

RealNumber ComplexNumber::GetA() const
{
	return a;
}

RealNumber ComplexNumber::GetB() const
{
	return b;
}

ComplexNumber ComplexNumber::operator+(const ComplexNumber & other)
{
	return ComplexNumber(a + other.a, b + other.b);
}

ComplexNumber ComplexNumber::operator-(const ComplexNumber & other)
{
	return ComplexNumber(a - other.a, b - other.b);
}

ComplexNumber ComplexNumber::operator/(const ComplexNumber & other)
{
	RealNumber c = other.a;
	RealNumber d = other.b;
	RealNumber newA = (a * c + b * d) / (c * c + d * d);
	RealNumber newB = (b * c - a * d) / (c * c + d * d);
	return ComplexNumber(newA, newB);
}

ComplexNumber ComplexNumber::operator*(const ComplexNumber & other)
{
	RealNumber c = other.a;
	RealNumber d = other.b;
	RealNumber newA = (a * c - b * d);
	RealNumber newB = (b * c + a * d);
	return ComplexNumber(newA, newB);
}

bool ComplexNumber::operator==(const ComplexNumber & other)
{
	return a == other.a && b == other.b;
}

ComplexNumber ComplexNumber::operator+(RealNumber & other)
{
	return ComplexNumber(a + other, b);
}

ComplexNumber ComplexNumber::operator-(RealNumber & other)
{
	return ComplexNumber(a - other, b);
}

ComplexNumber ComplexNumber::operator/(RealNumber & other)
{
	return ComplexNumber(a * other, b * other);
}

ComplexNumber ComplexNumber::operator*(RealNumber & other)
{
	return ComplexNumber(a / other, b / other);
}

bool ComplexNumber::operator==(const RealNumber & other)
{
	return a == other && b == RealNumber(0);
}

ostream & operator<<(ostream & os, ComplexNumber & complexNumber)
{
	RealNumber rA = complexNumber.GetA();
	RealNumber rB = complexNumber.GetB();
	return os << rA << " + " << rB << "i";
}