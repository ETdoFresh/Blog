#include "RealNumber.h"

RealNumber::RealNumber()
{
	a = 0;
}

RealNumber::RealNumber(float newA)
{
	a = newA;
}

RealNumber::RealNumber(const RealNumber & other)
{
	a = other.a;
}

RealNumber::~RealNumber()
{
}

float RealNumber::GetA() const
{
	return a;
}

RealNumber RealNumber::operator+(const RealNumber & other)
{
	return RealNumber(a + other.a);
}

RealNumber RealNumber::operator-(const RealNumber & other)
{
	return RealNumber(a - other.a);
}

RealNumber RealNumber::operator/(const RealNumber & other)
{
	return RealNumber(a / other.a);
}

RealNumber RealNumber::operator*(const RealNumber & other)
{
	return RealNumber(a * other.a);
}

bool RealNumber::operator==(const RealNumber & other)
{
	const float error = 0.00001f;
	float deltaA = a - other.a;
	return deltaA > -error && deltaA < error;
}

ostream & operator<<(ostream & os, RealNumber & realNumber)
{
	return os << realNumber.GetA();
}
