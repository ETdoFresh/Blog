#pragma once
#include <iostream>
using namespace std;

// RealNumber
// A number (float) that has no imaginary components
// Does not contain a factor of sqrt(-1)
class RealNumber
{
public:
	RealNumber();
	RealNumber(float newA);
	RealNumber(const RealNumber & other); // copy constructor
	~RealNumber();
	float GetA() const;

	RealNumber operator+(const RealNumber & other);
	RealNumber operator-(const RealNumber & other);
	RealNumber operator/(const RealNumber & other);
	RealNumber operator*(const RealNumber & other);
	bool operator==(const RealNumber & other);

protected:
	float a;
};

ostream & operator<<(ostream & os, RealNumber & realNumber);