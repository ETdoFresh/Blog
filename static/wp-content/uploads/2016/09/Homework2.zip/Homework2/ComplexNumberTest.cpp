// Homework 2 (Base): Complex Number Test
// This program tests the ComplexNumber class.

#include <iostream>
#include "ComplexNumber.h"
using namespace std;

#define FLT_MIN 1.175494e-38
#define FLT_MAX 3.402823e+38

float RandomFloat(float min = 0, float max = 1);
void TestConstructors();
void TestGetters();
void TestOperators();

int main(int argc, char* argv[])
{
	TestConstructors();
	TestGetters();
	TestOperators();
	cin.get();
	return 0;
}

ComplexNumber complexNumbers[] = {
	ComplexNumber(),
	ComplexNumber(ComplexNumber(1, -1)),
	ComplexNumber(FLT_MIN, FLT_MAX),
	ComplexNumber(RandomFloat(),RandomFloat()),
	ComplexNumber(RandomFloat(-99999, 99999),RandomFloat(-99999, 99999)),
};

float RandomFloat(float min, float max)
{
	float range = max - min;
	return ((float(rand()) / float(RAND_MAX)) * range) + min;
}

void TestConstructors()
{
	cout << "Testing Constructors" << endl;
	cout << "--------------------" << endl;
	for (ComplexNumber complexNumber : complexNumbers)
		cout << complexNumber << endl;
	cout << endl;
}

void TestGetters()
{
	cout << "Testing Getters" << endl;
	cout << "--------------------" << endl;
	for (ComplexNumber complexNumber : complexNumbers)
		cout << complexNumber.GetA() << " " << complexNumber.GetB() << endl;
	cout << endl;
}

void TestOperators()
{
	cout << "Testing Arithmetic" << endl;
	cout << "--------------------" << endl;
	for (ComplexNumber complexNumber1 : complexNumbers)
		for (ComplexNumber complexNumber2 : complexNumbers)
		{
			ComplexNumber result = complexNumber1 + complexNumber2;
			cout << "(" << complexNumber1 << ") + (" << complexNumber2 << ") = ";
			cout << result << endl;

			result = complexNumber1 - complexNumber2;
			cout << "(" << complexNumber1 << ") - (" << complexNumber2 << ") = ";
			cout << result << endl;

			result = complexNumber1 * complexNumber2;
			cout << "(" << complexNumber1 << ") * (" << complexNumber2 << ") = ";
			cout << result << endl;

			result = complexNumber1 / complexNumber2;
			cout << "(" << complexNumber1 << ") / (" << complexNumber2 << ") = ";
			cout << result << endl;

			bool resultBool = complexNumber1 == complexNumber2;
			cout << "(" << complexNumber1 << ") == (" << complexNumber2 << ") = ";
			cout << resultBool << endl;
		}
	cout << endl;
}