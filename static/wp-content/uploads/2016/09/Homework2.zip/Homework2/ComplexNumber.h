#pragma once
#include <iostream>
using namespace std;

// ComplexNumber
// A number that is represented in the form a + bi
// Where a and b are real numbers and i^2 = -1
class ComplexNumber
{
public:
	ComplexNumber();
	ComplexNumber(float newA, float newB);
	ComplexNumber(const ComplexNumber & other); // copy constructor
	~ComplexNumber();
	float GetA() const;
	float GetB() const;
	ComplexNumber operator+(const ComplexNumber & other);
	ComplexNumber operator-(const ComplexNumber & other);
	ComplexNumber operator/(const ComplexNumber & other);
	ComplexNumber operator*(const ComplexNumber & other);
	bool operator==(const ComplexNumber & other);

protected:
	float a;
	float b;
};

ostream & operator << (ostream& os, ComplexNumber& complexNumber);