#include "ComplexNumber.h"

ComplexNumber::ComplexNumber()
{
	a = 0;
	b = 0;
}

ComplexNumber::ComplexNumber(float newA, float newB)
{
	a = newA;
	b = newB;
}

ComplexNumber::ComplexNumber(const ComplexNumber & other)
{
	a = other.a;
	b = other.b;
}

ComplexNumber::~ComplexNumber()
{
}

float ComplexNumber::GetA() const
{
	return a;
}

float ComplexNumber::GetB() const
{
	return b;
}

ComplexNumber ComplexNumber::operator+(const ComplexNumber & other)
{
	return ComplexNumber(a + other.a, b + other.b);
}

ComplexNumber ComplexNumber::operator-(const ComplexNumber & other)
{
	return ComplexNumber(a - other.a, b - other.b);
}

ComplexNumber ComplexNumber::operator/(const ComplexNumber & other)
{
	float c = other.a;
	float d = other.b;
	float newA = (a * c + b * d) / (c * c + d * d);
	float newB = (b * c - a * d) / (c * c + d * d);
	return ComplexNumber(newA, newB);
}

ComplexNumber ComplexNumber::operator*(const ComplexNumber & other)
{
	float c = other.a;
	float d = other.b;
	float newA = (a * c - b * d);
	float newB = (b * c + a * d);
	return ComplexNumber(newA, newB);
}

bool ComplexNumber::operator==(const ComplexNumber & other)
{
	float deltaA = a - other.a;
	float deltaB = b - other.b;
	bool aEqual = deltaA > -0.00001f && deltaA < 0.00001f;
	bool bEqual = deltaB > -0.00001f && deltaB < 0.00001f;
	return aEqual && bEqual;
}

ostream & operator<<(ostream & os, ComplexNumber & complexNumber)
{
	return os << complexNumber.GetA() << " + " << complexNumber.GetB() << "i";
}