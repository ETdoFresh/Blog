/**
 * Efficient broad phase collision detection using the popular Sweep and Prune
 * method.
 */
package com.stephengware.java.games.physics_game.collision;