/**
 * Simulated bodies that move around in a 2D space and change direction when
 * they collide.
 */
package com.stephengware.java.games.physics_game.physics;